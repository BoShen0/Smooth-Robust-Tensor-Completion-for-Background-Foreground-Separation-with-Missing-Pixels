%%% Demo for Image Recovery
%
% If you have any questions about the code, 
% feel free to contact Fanhua Shang: fhshang@cse.cuhk.edu.hk 
% 

clc; clear; 
addpath('image recovery');
addpath('image recovery\pic');

% Color Images
pic_list = {'re1.jpg','re2.jpg','re3.jpg','re4.jpg','re5.jpg','re6.jpg','re7.jpg','re8.jpg'};


results = zeros(3, 8);
times   = zeros(3, 8);

for ii =  1:8
    
    % Input data
    imagenum = ii;
    pic_name = pic_list{imagenum};
    Xfull    = double(imread(pic_name));                   
    sr = 0.15;      
    disp('85% pixels are missing');
    sizem = size(Xfull,1); sizen = size(Xfull,2);
    ind   = double(rand(sizem,sizen) < sr);
    mask  = zeros(sizem, sizen, 3);
    mask(:,:,1) = ind; mask(:,:,2) = ind; mask(:,:,3) = ind;
    mask = logical(mask);  
    Data = zeros(sizem, sizen, 3);
    Data(mask) = Xfull(mask);
               
    % Parameter settings
    ranks   = 9;
    lambda  = 2*sqrt(max(sizem, 2*sizen));
    tol     = 1e-4; 
    maxIter = 200;         
    Xrec1 = zeros(sizem, sizen, 3);
    Xrec2 = zeros(sizem, sizen, 3);  
    Xrec3 = zeros(sizem, sizen, 3);
    
    
    %%% WNNM
    % S. Gu, Q. Xie, D. Meng, W. Zuo, X. Feng, and L. Zhang, 
    % Weighted nuclear norm minimization and its applications to low level vision, 
    % Int. J. Comput. Vis., 2016. 
    tic
    Xrec1 = WNNM_main(Data, mask);
    time1 = toc;
    Xrec1 = max(Xrec1,0);
    Xrec1 = min(Xrec1,255);
    results(1,ii) = PSNR(Xfull, Xrec1)
    times(1,ii)= time1; 
    
    
    %%% Double nuclear norm (D-N) penalty 
    tic
    Xrec2 = DN12_main(Data, mask, ranks, lambda, tol, maxIter);
    time2 = toc;   
    Xrec2 = max(Xrec2, 0);
    Xrec2 = min(Xrec2, 255);
    results(2, ii) = PSNR(Xfull, Xrec2)
    times(2, ii) = time2; 
    
    
    %%% Frobenius/nuclear norm (F-N) penalty
    tic
    Xrec3 = FN23_main(Data, mask, ranks, lambda, tol, maxIter); 
    time3 = toc;          
    Xrec3 = max(Xrec3, 0);
    Xrec3 = min(Xrec3, 255);
    results(3, ii) = PSNR(Xfull, Xrec3)
    times(3, ii) = time3;
       
end

figure(31)
bar(results')
xlabel('Index')
ylabel('PSNR')
legend('WNNM','D-N','F-N',2);
axis([0.5 8.5 15 30]);


figure(32)
bar(times')
xlabel('Index')
ylabel('Time (seconds)')
legend('WNNM','D-N','F-N');
axis([0.5 8.5 1 max(times(1,:))]);

