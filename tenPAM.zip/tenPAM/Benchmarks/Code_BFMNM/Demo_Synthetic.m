% Demo Codes for Synthetic Data
%
% If you have any questions about the code, 
% feel free to contact Fanhua Shang: fhshang@cse.cuhk.edu.hk 
% 

clc; clear; 
addpath('toy');

sizes = [500,1000]; %%% Size of matrices
r = 10; % True rank

results = [];  
for jj = 1:2
    
    %%% Prepare the data
    m = sizes(jj); n = sizes(jj);
    AA = randn(m, r); AB = randn(n, r);
    M  = AA*AB';
    clear AA AB
    D  = M + 0.5*randn(m,n);
    S0 = rand(size(M)) > 0.8;
    outNum = sum(sum(S0));
    D(S0) = rand(outNum, 1) * 10 - 5;
    clear outNum
    
    %%% Parameters
    maxIter = 500; 
    tol     = 1e-5; 
       
    %%% PSVT
    % T.-H. Oh, Y.-W. Tai, J.-C. Bazin, H. Kim, and I. S. Kweon, 
    % Partial sum minimization of singular values in robust PCA: Algorithm and applications,
    % IEEE Trans. Pattern Anal. Mach. Intell., vol. 38, no. 4, pp. 744�758.
    % 2016.
    lambda = sqrt(max(m, n));   
    tic
    [L1, S1] = RNSC(D, rank_estimation(D), 1/lambda, tol);
    Time1 =toc
    RSE1 = norm(L1 - M,'fro')/norm(M,'fro')
            
            
    %%% WNNM
    % S. Gu, Q. Xie, D. Meng, W. Zuo, X. Feng, and L. Zhang, 
    % Weighted nuclear norm minimization and its applications to low level vision, 
    % Int. J. Comput. Vis., 2016.
    lambda = sqrt(max(m, n));
    tic
    [L2, S2] = inexact_alm_WNNM_RPCA(D, lambda, eps, tol);
    Time2 = toc    
    RSE2 = norm(L2 - M,'fro')/norm(M,'fro')      
    
    
    %%% Our (S+L)1/2 method
    lambda  = sqrt(max(m, n))/2;
    ranks   = -1; % Our rank estimation procedure
    tic
    [L3, S3] = S12L12_full(D, ranks, lambda, tol, maxIter, 1.49);
    Time3 = toc
    RSE3 = norm(L3 - M,'fro')/norm(M,'fro')


    %%% Our (S+L)2/3 method  
    tic
    [L4, S4] = S23L23_full(D, ranks, lambda, tol, maxIter, 1.49);
    Time4 = toc
    RSE4 = norm(L4 - M,'fro')/norm(M,'fro')
    
    results = [results;RSE1,RSE2,RSE3,RSE4,Time1,Time2,Time3,Time4];
    
end 


%%% Plot
figure(21)
set(gcf,'position',[300,300,516,409]) 
h1 = bar(sizes, results(:,1:4)); 
ch = get(h1,'children');
ylabel('RSE');
legend('PSVT','WNNM','(S+L)_{1/2}','(S+L)_{2/3}');
axis([300 1200 0.02 0.12]);

figure(22)
set(gcf,'position',[300,300,516,409]) 
h1 = bar(sizes, results(:,5:8)); 
ch = get(h1,'children');
ylabel('Running time (seconds)');
legend('PSVT','WNNM','(S+L)_{1/2}','(S+L)_{2/3}',2);

