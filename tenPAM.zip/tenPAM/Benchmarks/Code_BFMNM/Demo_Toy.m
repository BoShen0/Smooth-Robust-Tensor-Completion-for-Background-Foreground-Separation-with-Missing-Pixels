% Demo for toy image
%
% If you have any questions about the code, 
% feel free to contact Fanhua Shang: fhshang@cse.cuhk.edu.hk 
% 

clc; clear;
addpath('toy');
    
% Prepare the data
pic = imread('original.png');
L0  = double(pic(:,:,1));
r   = rank(L0);
L0  = (L0 - 128) / 128;
pic = imread('error.png');
S0  = pic(:,:,1)==255;
clear pic

% Input
Grank  = fix(1.5*r); % Given rank
D      = L0;
outNum = sum(sum(S0));
D(S0)  = rand(outNum, 1) * 10 - 5;
[m, n] = size(L0);
W1 = rand(m, n) > 0.05;
W  = W1 | S0; 
WC = logical(1-double(W));
DD = rand(m, n);
D(WC) = DD(WC);
clear DD W1 outNum


%%% PCP (Robust PCA)
% E. Candes, X. Li, Y. Ma and J. Wright, Robust Principal Component
% Analysis? J. ACM, 2011.
lambda = sqrt(max(m,n));
tic;
[L1, E1] = PCP(D, 1/lambda, 1e-4, Grank);
time1 = toc
E1(WC) = 0;
% We choose the threshold to maximize the F measure.
[f1, S1] = findFMeasure(abs(E1), S0);

figure (1);
subplot(2,2,1),imshow(D,[-1,1]),colormap gray; axis off; 
title('Input');
subplot(2,2,2),imshow(L0,[]),colormap gray; axis off; 
title('Ground Truth');
subplot(2,2,3),imshow(S1,[]),colormap gray; axis off; 
title(['PCP, F-M = ', num2str(f1)]);
subplot(2,2,4),imshow(L1,[-1,1]),colormap gray; axis off; 
title(['PCP, RSE = ', num2str(norm(L0-L1,'fro')/norm(L0,'fro'))]);



%%% Schatten-p + Lp via ALM
% F. Nie, H. Wang, X. Cai, H. Huang, and C. Ding, 
% Robust matrix completion via joint Schatten p-norm and Lp-norm minimization,
% in Proc. IEEE Int. Conf. Data Mining, 2012, pp. 566�574.
p = 0.98;
tic
L2  = LpRtracep(D, W, Grank, p);
time2 = toc
E2 = D - L2; E2(WC) = 0;
[f2, S2] = findFMeasure(abs(E2), S0);

figure (2);
subplot(2,2,1),imshow(D,[-1,1]),colormap gray; axis off; 
title('Input');
subplot(2,2,2),imshow(L0,[]),colormap gray; axis off; 
title('Ground Truth');
subplot(2,2,3),imshow(S2,[]),colormap gray; axis off; 
title(['LpSp, F-M = ', num2str(f2)]);
subplot(2,2,4),imshow(L2,[-1,1]), colormap gray; axis off; 
title(['LpSp, RSE = ', num2str(norm(L0-L2,'fro')/norm(L0,'fro'))]);
clear p; 


%%% WNNM
% S. Gu, Q. Xie, D. Meng, W. Zuo, X. Feng, and L. Zhang, 
% Weighted nuclear norm minimization and its applications to low level vision, 
% Int. J. Comput. Vis., 2016.
lambda = sqrt(max(m, n));
tic
[L3, E3] = inexact_alm_WNNM_RPCA(D, lambda, eps, 1e-5);
time3 = toc
E3(WC)= 0;
[f3, S3] = findFMeasure(abs(E3), S0);

figure (3);
subplot(2,2,1),imshow(D,[-1,1]),colormap gray; axis off; 
title('Input');
subplot(2,2,2),imshow(L0,[]),colormap gray; axis off; 
title('Ground Truth');
subplot(2,2,3),imshow(S3,[]),colormap gray; axis off; 
title(['WNNM, F-M = ', num2str(f3)]);
subplot(2,2,4),imshow(L3,[-1,1]), colormap gray; axis off; 
title(['WNNM, RSE = ', num2str(norm(L0-L3,'fro')/norm(L0,'fro'))]);


%%% Unifying
% R. Cabral, F. De la Torre, J. Costeira, and A. Bernardino, 
% Unifying nuclear norm and bilinear factorization approaches for low-rank matrix decomposition,
% in Proc. IEEE Int. Conf. Comput. Vis., pp. 2488�2495, 2013.
lambda = sqrt(max(m, n));
tic;
L4 = Unifying(D, W, Grank, lambda);
time4 = toc
E4 = D - L4; E4(WC) = 0;
[f4, S4] = findFMeasure(abs(E4), S0);

figure (4);
subplot(2,2,1),imshow(D,[-1,1]),colormap gray; axis off; 
title('Input');
subplot(2,2,2),imshow(L0,[]),colormap gray; axis off; 
title('Ground Truth');
subplot(2,2,3),imshow(S4,[]),colormap gray; axis off; 
title(['Unifying, F-M = ', num2str(f4)]);
subplot(2,2,4),imshow(L4,[-1,1]),colormap gray; axis off; 
title(['Unifying, RSE = ', num2str(norm(L0-L4,'fro')/norm(L0,'fro'))]);



%%% Our (S+L)1/2 Method
lambda = sqrt(max(m, n))/1.5;
tic
[L5, E5] = S12L12(D, W, Grank, lambda);
time5 = toc
E5(WC) = 0;
[f5, S5] = findFMeasure(abs(E5), S0);

figure (5);
subplot(2,2,1),imshow(D,[-1,1]),colormap gray; axis off; 
title('Input');
subplot(2,2,2),imshow(L0,[]),colormap gray; axis off; 
title('Ground Truth');
subplot(2,2,3),imshow(S5,[]),colormap gray; axis off; 
title(['(S+L)_{1/2}, F-M = ', num2str(f5)]);
subplot(2,2,4),imshow(L5,[-1,1]), colormap gray; axis off; 
title(['(S+L)_{1/2}, RSE = ', num2str(norm(L0-L5,'fro')/norm(L0,'fro'))]);



%%% Our (S+L)2/3 Method
lambda = sqrt(max(m, n))/1.85;
tic
[L6, E6] = S23L23(D, W, Grank, lambda);
time6 = toc
E6(WC) = 0;
[f6, S6] = findFMeasure(abs(E6), S0);

figure (6);
subplot(2,2,1),imshow(D,[-1,1]),colormap gray; axis off; 
title('Input');
subplot(2,2,2),imshow(L0,[]),colormap gray; axis off; 
title('Ground Truth');
subplot(2,2,3),imshow(S6,[]),colormap gray; axis off; 
title(['(S+L)_{2/3}, F-M = ', num2str(f6)]);
subplot(2,2,4),imshow(L6,[-1,1]), colormap gray; axis off; 
title(['(S+L)_{2/3}, RSE = ', num2str(norm(L0-L6,'fro')/norm(L0,'fro'))]);

imshow(L6)

%%% Plot results
figure (11); % Sparse component 
subplot(2,3,1),imshow(S1,[]),colormap gray; axis off; 
title(['PCP, F-M = ', num2str(f1)]);
subplot(2,3,2),imshow(S2,[]),colormap gray; axis off; 
title(['LpSp, F-M = ', num2str(f2)]);
subplot(2,3,3),imshow(S3,[]),colormap gray; axis off; 
title(['WNNM, F-M = ', num2str(f3)]);
subplot(2,3,4),imshow(S4,[]),colormap gray; axis off; 
title(['Unifying, F-M = ', num2str(f4)]);
subplot(2,3,5),imshow(S5,[]),colormap gray; axis off; 
title(['(S+L)_{1/2}, F-M = ', num2str(f5)]);
subplot(2,3,6),imshow(S6,[]),colormap gray; axis off; 
title(['(S+L)_{2/3}, F-M = ', num2str(f6)]);


figure (12); % Low-rank component 
subplot(2,3,1),imshow(L1,[-1,1]), colormap gray; axis off; 
title(['PCP, RSE = ', num2str(norm(L0-L1,'fro')/norm(L0,'fro'))]);
subplot(2,3,2),imshow(L2,[-1,1]), colormap gray; axis off; 
title(['LpSp, RSE = ', num2str(norm(L0-L2,'fro')/norm(L0,'fro'))]);
subplot(2,3,3),imshow(L3,[-1,1]), colormap gray; axis off; 
title(['WNNM, RSE = ', num2str(norm(L0-L3,'fro')/norm(L0,'fro'))]);
subplot(2,3,4),imshow(L4,[-1,1]), colormap gray; axis off; 
title(['Unifying, RSE = ', num2str(norm(L0-L4,'fro')/norm(L0,'fro'))]);
subplot(2,3,5),imshow(L5,[-1,1]), colormap gray; axis off; 
title(['(S+L)_{1/2}, RSE = ', num2str(norm(L0-L5,'fro')/norm(L0,'fro'))]);
subplot(2,3,6),imshow(L6,[-1,1]), colormap gray; axis off; 
title(['(S+L)_{2/3}, RSE = ', num2str(norm(L0-L6,'fro')/norm(L0,'fro'))]);

