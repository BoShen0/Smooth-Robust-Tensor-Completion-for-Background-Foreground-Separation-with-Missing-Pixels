The code in this package implements the Bilinear Factor Matrix Norm Minimization (BFMNM) for robust PCA and matrix completion as described in the following paper:

 @Article{BFMNM,
 	author = {Fanhua Shang and James Cheng and Yuanyuan Liu and Zhi-Quan Luo and Zhouchen Lin},
 	title = {Bilinear Factor Matrix Norm Minimization for Robust PCA: Algorithms and Applications},
 	journal = {IEEE Transactions on Pattern Analysis and Machine Intelligence},
 	year = {2017}
 }

Please cite the paper if you are using this code in your research.

  Version:       1.0 (19/01/2017)
  Contact:       Fanhua Shang 
  E-mails:       fhshang@cse.cuhk.edu.hk or shangfanhua@hotmail.com

% ================================================================= %

Notice: The MATLAB code can be downloaded using the following link:

https://www.dropbox.com/s/npyc2t5zkjlb7tt/Code_BFMNM.zip?dl=0.

% ================================================================= %

Description: 
This code is implemented in Matlab2014a.

The function "Demo_Synthetic" demonstrates the experimental results (including RSE and running time) of the two propsoed methods, as well as the two well-known methods: PSVT and WNNM, on synthetic data. 

The function "Demo_Toy" demonstrates real text removal with "ground truth" by some existing methods (including PCP, PSVT, WNNM, Unifying, and LpSq) and the two proposed methods.

The function "Demo_Images" demonstrates color image inpainting by the well-known method, WNNM, and the two proposed methods, where the eight natural images were used in the following paper:
[1] Yao Hu, Debing Zhang, Jieping Ye, Xuelong Li, Xiaofei He, Fast and Accurate Matrix Completion via Truncated Nuclear Norm Regularization. IEEE Transactions on Pattern Analysis and Machine Intelligence, 2013.


Contact:
If you have any questions or suggestions with the code, or find a bug, please let us know. 
Contact Fanhua Shang at fhshang@cse.cuhk.edu.hk or shangfanhua@hotmail.com.

