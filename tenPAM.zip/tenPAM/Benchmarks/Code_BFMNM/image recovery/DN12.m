function [X, errList] = DN12(T, Omega, ranks, lambda, tol, maxIter)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%       Double Nuclear Norm Minimization (DNNM) for Image Recovery
%  
%
% min_{U,V,U',V',X}: 1/2*(|U'|_{*}+|V'|_{*})+lambda/2*|P_{Omega}(X)-P_{Omega}(D)|^2_{F},
% s.t., X = UV^{T}, U = U', V = V'.
%       
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%Input: 
%    T:        Input data matrix of size m*n 
%    Omega:    Indicator matrix of size m*n, with '1' means 'observed', and '0' 'missing'
%    ranks:    Given rank
%    lambda:   Regularization paramter
%    tol:      Tolerance for stopping criterion
%    maxIter:  Maximum iteration number, usually 500.
%
%Output:
%    X : m*n   Low-rank recovered matrix
%    errList : Difference
%
% created by Fanhua Shang on 2/19/2016, fhshang@cse.cuhk.edu.hk
%

% Default parameters
if nargin < 6
    maxIter = 1000; 
end

if nargin < 5
    tol = 1e-4; 
end

if nargin < 4
    [Umax,Smax,Vmax] = lansvd(sparse(T),1,'L',options);
    mumax  = max(diag(Smax));   
    lambda = 1/mumax; 
end

if nargin < 3
    ranks = round(1.2*rank_estimation(T));
end

%%% Initialization
alpha = [0.5, 0.5];
rho   = 1.05; 
beta  = 1e-4;
max_beta = 1e20;
[ncr(1,1), ncr(1,2)] = size(T); 

X  = full(T);   
TT = T(Omega);
X(logical(1-Omega)) = mean(TT); 

errList = zeros(maxIter, 1);
normT   = norm(TT(:)); 

for i  = 1:2 
    M{i} = rand(size(X, 3-i), ranks);
    if i == 1
        [U{i} aa] = qr(X*M{i}, 0);
    end
    if i == 2
        [U{i} aa] = qr(X'*M{i}, 0);
    end
    Y{i} = zeros(size(X, i), ranks); 
    M{i} = Y{i}; 
end
clear aa 
% for ii = 1:2
%     U{ii}    = rand(ncr(1, ii), ranks)/2; 
%     Y{ii}    = zeros(ncr(1, ii), ranks);
%     M{ii}    = Y{ii};
%     temp{ii} = Y{ii};
% end
% L  = sign(T);
% a1 = norm(L, 2); a2 = norm(L, Inf)*lambda;
% Y{3} = L/max(a1, a2);
Y{3} = zeros(ncr(1,1), ncr(1,2));
clear L T
XX = Y{3};

stop_temp = zeros(2, 1);

%%% Iteration Scheme
for Iter = 1: maxIter
    
    if mod(Iter, 50) == 0
        fprintf('DN12: iterations = %d  beta = %d  difference=%f\n', Iter, beta, errList(Iter-1));
    end
    
    beta1 = 1/beta;
    
    % update M1 and M2  
    for i = 1:2           
        [UU, sigma, VV] = svd(U{i} + Y{i}*beta1, 'econ'); 
        sigma = diag(sigma);
        svp = length(find(sigma > alpha(i)*beta1)); 
        if svp>=1
            sigma = sigma(1:svp) - alpha(i)*beta1;
        else
            svp   = 1;
            sigma = 0;
        end
        M{i} = UU(:,1:svp)*diag(sigma(1:svp))*VV(:,1:svp)';
    end    
           
    % update U1 and U2
    XX   = X*beta + Y{3};
    U{1} = (XX*U{2} + M{1}*beta - Y{1})*inv((beta*U{2}'*U{2}) + (beta+1)*eye(ranks));
    U{2} = (M{2}*beta - Y{2} + XX'*U{1})*inv((beta+1)*eye(ranks) + beta*(U{1}'*U{1}));

      
    % update X 
    XX = U{1}*U{2}';      
    X  = XX - Y{3}*beta1;
    X(Omega) = X(Omega)*(beta/(beta+lambda)) + TT*(lambda/(beta+lambda));    
    
    
    % update Lagrange multipliers 
    E = X - XX;
    for i = 1:3 
        if i < 3
            temp{i} = U{i} - M{i};           
            Y{i}    = Y{i} + temp{i}*beta;                       
            stop_temp(i) = norm(temp{i}(:), 'fro');
        else
            Y{3} = Y{3} + E*beta;
            stop_temp(i) = norm(E(:), 'fro');
        end
    end   
    X = max(X, 0); X = min(X, 255);
    
    stopC = max(stop_temp)/normT;
    errList(Iter) = stopC;
 
    if stopC < tol
        break;
    else
        beta = min(beta * rho, max_beta);
    end
    if Iter == 60
       rho = 1.03;
    end
    
end 
errList = errList(1:Iter);
end

