function [X, errList] = FN23(T, Omega, ranks, lambda, tol, maxIter)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%     Frobenius/Nuclear Norm Minimization (FNNM) for Image Recovery 
% 
%
% min_{U,V,U',X}: 1/3*(2*|U'|_{*}+|V|^{2}_{F}) + lambda/2*|P_{Omega}(X)-P_{Omega}(D)|^2_{F},
% s.t., X = UV^{T}, U = U'.
%       
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%Input: 
%    T:        Input data matrix of size m*n 
%    Omega:    Indicator matrix of size m*n, with '1' means 'observed', and '0' 'missing'
%    ranks:    Given rank
%    lambda:   Regularization paramter
%    tol:      Tolerance for stopping criterion
%    maxIter:  Maximum iteration number, usually 500.
%
%Output:
%    X : m*n   Low-rank recovered matrix
%    errList : Difference
%
% created by Fanhua Shang on 2/19/2016, fhshang@cse.cuhk.edu.hk
%

% Default parameters
if nargin < 6
    maxIter = 500; 
end

if nargin < 5
    tol = 1e-4; 
end

if nargin < 4
    [Umax,Smax,Vmax] = lansvd(sparse(T),1,'L');
    mumax  = max(diag(Smax));   
    lambda = 1/mumax; 
end

if nargin < 3
    ranks = round(1.2*rank_estimation(T));
end

%%% Initialization
alpha   = [2/3, 1/3];
rho     = 1.05; 
beta    = 1e-4;
max_beta = 1e20;
[ncr(1,1), ncr(1,2)] = size(T); 

X  = full(T);   
TT = T(Omega);

X(logical(1-Omega)) = mean(TT); 

errList = zeros(maxIter, 1);
normT   = norm(TT(:)); 

M1 = rand(ncr(1,1), ranks);
Y1 = zeros(ncr(1,1), ranks);
temp1 = Y1; 

for ii = 1:2
    U{ii} = rand(ncr(1, ii), ranks);   
end
% L  = sign(X);
% a1 = norm(L, 2); a2 = norm(L, Inf)*lambda;
% Y2 = L/max(a1, a2);
clear L T
Y2 = zeros(ncr(1,1), ncr(1,2));
XX = Y2;

stop_temp = zeros(2, 1);

%%% Iteration Scheme
for Iter = 1: maxIter
    
    if mod(Iter, 50) == 0
        fprintf('FN23: iterations = %d  beta = %d  difference=%f\n', Iter, beta, errList(Iter-1));
    end    
    beta1 = 1/beta;

    % update M1           
    [UU, sigma, VV] = svd(U{1} - Y1*beta1, 'econ'); 
    sigma = diag(sigma);
    svp = length(find(sigma > alpha(1)*beta1)); 
    if svp>=1
        sigma = sigma(1:svp) - alpha(1)*beta1;
    else
        svp = 1;
        sigma = 0;
    end
    M1 = UU(:,1:svp)*diag(sigma(1:svp))*VV(:,1:svp)';   
           
    % update U1 and U2
    XX   = X + Y2*beta1;
    U{1} = (XX*U{2}*beta + beta*M1 + Y1)*inv(beta*(U{2}'*U{2}) + (4/3+beta)*eye(ranks));
    U{2} = beta*(XX'*U{1})*inv(2*eye(ranks) + beta*(U{1}'*U{1}));
      
    % update X 
    XX = U{1}*U{2}';      
    X  = XX - Y2*beta1;
    X(Omega) = X(Omega)*(beta/(beta+lambda)) + TT*(lambda/(beta+lambda));    
    
    
    % update Lagrange multipliers 
    XX = X - XX;
    for i = 1:2 
        if i < 2
            temp1 = M1 - U{i};           
            Y1    = Y1 + temp1*beta;                       
            stop_temp(i) = norm(temp1(:), 'fro');
        else
            Y2 = Y2 + XX*beta;
            stop_temp(i) = norm(XX(:), 'fro');
        end
    end
   
    X = max(X, 0); X = min(X, 255);

    stopC = max(stop_temp)/normT;
    errList(Iter) = stopC;
 
    if stopC < tol
        break;
    else
        beta = min(beta * rho, max_beta);
    end
    if Iter == 60
       rho = 1.03;
    end
    
end 
errList = errList(1:Iter);
end
