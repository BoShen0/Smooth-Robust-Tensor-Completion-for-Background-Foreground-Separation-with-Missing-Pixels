function Xrecover = FN23_main(TT, mask, ranks, lambda, tol, maxIter)

sizem  = size(TT,1); sizen = size(TT,2);
lambda = 1/lambda;
index  = [1, 2; 2, 3; 3, 1];
Xrecover = zeros(sizem, sizen, 3); 

for kk = 1:3
    mask1 = [mask(:,:,index(kk, 1)), mask(:,:,index(kk, 2))];
    mask1 = logical(mask1);
    data  = [TT(:,:, index(kk, 1)), TT(:,:, index(kk, 2))];   
    Xrecover1 = FN23(data, mask1, ranks, lambda, tol, maxIter);                        
    Xrecover(:,:,kk) = Xrecover1(:, 1:sizen);
end  