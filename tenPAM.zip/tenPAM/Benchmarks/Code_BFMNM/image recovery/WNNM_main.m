function Xrecover = WNNM_main(TT, mask)

sizem = size(TT,1); 
sizen = size(TT,2);
index = [1, 2; 2, 3; 3, 1];

Xrecover = zeros(sizem, sizen, 3); 

for kk = 1:3
    mask1 = [mask(:,:,index(kk, 1)), mask(:,:,index(kk, 2))];
    mask1 = logical(mask1);
    data  = [TT(:,:, index(kk, 1)), TT(:,:, index(kk, 2))];                                  
    Xrecover1 = inexact_alm_WNNM_MC(data, mask1, sqrt(2*sizem*sizen), eps, 1e-4, -1);                        
    Xrecover(:,:,kk) = Xrecover1(:, 1:sizen);
end    