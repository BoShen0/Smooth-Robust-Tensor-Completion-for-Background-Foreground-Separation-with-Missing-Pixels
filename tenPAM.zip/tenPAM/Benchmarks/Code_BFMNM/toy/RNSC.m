function [L S iter] = RNSC(D, rankN, lambda, tol, maxIter)
%% Rank N soft constraint for RPCA (Ver. 1.0)
% 
%	This code follows and refers the Copyright and Intelligent Property codes of Korea Advanced Institute of Science and Technology.
%	<Input>
%	D : [m x n] observation matrix (Notice: must be m>>n)
%	rankN : target rank N
%
%	<Output>
%	L : [m x n] low-rank matrix
%	S : [m x n] sparse matrix
%	
%%   
%   
%   This code is written by Tae-Hyun Oh, based on Minming Chen and
%   Arvind Ganesh's code. Also, this is for the paper,
%
%   T. Oh, H. Kim, Y.-W. Tai, J.C. Bazin and I.S. Kweon,	
%   "Partial Sum Minimization of Singular Values in RPCA for Low-Level
%   Vision", ICCV, 2013, and 
%   T. Oh, Y.-W. Tai, J.C. Bazin, H. Kim and I.S. Kweon,	
%   "Partial Sum Minimization of Singular Values in Robust PCA: Algorithm
%   and Applications", TPAMI, to appear.
%
%   This release is for research usage. 
%   Email me with questions and comments: thoh.kaist.ac.kr@gmail.com, I'll help you.
% 
%   [For more information]
%   http://thoh.kaist.ac.kr/
%   http://thoh.kaist.ac.kr/Research/PartialSum/PartialSum.htm
% 
%                                                                   Seoul, Korea.
%                                                                   Jan.
%                                                                   3. 2014.
% 
%%% 
flag_transpose = 0;
[m n] = size(D);

if m < n
    flag_transpose = 1;
	D = D';
	[m n] = size(D);
end

if nargin < 3
    lambda = 1 / sqrt(m);
end

if nargin < 4
    tol = 1e-7;
elseif tol == -1
    tol = 1e-7;
end

if nargin < 5
    maxIter = 1000;
elseif maxIter == -1
    maxIter = 1000;
end

% initialize
Y = D;						% can be tuned
norm_two = norm(Y, 2);
norm_inf = norm( Y(:), inf) / lambda;
dual_norm = max(norm_two, norm_inf);
Y = Y / dual_norm;

L  = zeros( m, n);			% can be tuned
S  = zeros( m, n);			% can be tuned
mu = 1.25/norm_two; 		% can be tuned
mu_bar = mu * 1e7;
rho = 1.5;          		% can be tuned
d_norm = norm(D, 'fro');

iter = 0;
converged = false;
stopCriterion = 1;

while ~converged       
    iter = iter + 1;
    
    %%% E
    temp_T = D - L + (1/mu)*Y;
    S = max(temp_T - lambda/mu, 0);
    S = S+min(temp_T + lambda/mu, 0);
    
    %%% A
    [U, Singular, V] = svd(D - S + (1/mu)*Y, 'econ');
    diagS = diag(Singular);
    svp = length(find(diagS > 1/mu));
    
    if svp <= rankN
        dterm = diag( diagS(1:svp) );
    else
        dterm = diag( [diagS(1:rankN);diagS(rankN+1:svp) - 1/mu] );
    end
    L = U(:, 1:svp) * dterm * V(:, 1:svp)';    

    
    Z = D - L - S;
    Y = Y + mu*Z;
    mu = min(mu*rho, mu_bar);
        
    stopCriterion = norm(Z, 'fro') / d_norm;
    if stopCriterion < tol
        converged = true;
    end    
    
    if ~converged && iter >= maxIter
        disp('Maximum iterations reached') ;
        converged = 1 ;       
    end
end

if flag_transpose
    L = L';
    S = S';
end
