function [X, S, errList] = S12L12(T, Omega, ranks, lambda, tol, maxIter, rho, beta)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%       Tractable Double Nuclear Norm Minimization for Robust PCA
% 
%
% min_{Un,Mn,L,S}: 0.5*lambda*(\|U1\|_{*}+\|U2\|_{*})+\|S_{Omega}\|^{1/2}_{1/2},
% s.t. L + S = D, L = M1M2', Un = Mn, n = 1, 2.
%       
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%Input: 
%    T:        Input data matrix of size m*n 
%    Omega:    Indicator matrix of size m*n, with '1' means 'observed', and '0' 'missing'
%    ranks:    Given rank
%    lambda:   Regularization paramter
%    tol:      Tolerance for stopping criterion
%    maxIter:  Maximum iteration number, usually 500
%    rho:      Initial value of the parameter 
%    beta:     Penalty parameter, it should be small enough
%
%Output:
%    X : m*n   Low-rank component
%    S : m*n   Sparse component
%    errList : Difference
%
% created by Fanhua Shang on 3/6/2016, fhshang@cse.cuhk.edu.hk
%

% Default parameters
[nc, nr] = size(T); 

if nargin < 8
    beta = 2*1e-3;
end

if nargin < 7
    rho = 1.05; 
end

if nargin < 6
    maxIter = 500; 
end

if nargin < 5
    tol = 1e-4; 
end

if nargin < 4
    lambda = sqrt(max(nc,nr)); 
end

if nargin < 3
    ranks = round(1.2*rank_estimation(T));
end

%%% Initialization
alpha    = [0.5, 0.5];
max_beta = 1e20;
normT    = norm(T(:)); 

for i  = 1:2 
     M{i} = randn(size(T, 3-i), ranks);
    if i == 1
        [U{i} aa] = qr(T*M{i}, 0);
    else
        [U{i} aa] = qr(T'*M{i}, 0);
    end
    %U{i} = eye(size(T, i), ranks); 
    Y{i} = zeros(size(T, i), ranks); 
    M{i} = Y{i}; 
end
L  = sign(T); a1 = norm(L, 2); a2 = norm(L, Inf)/lambda;
Y3 = L/max(a1,a2);
clear aa a1 a2 
Y4 = Y3;
%Y3 = zeros(nc, nr);
S  = sparse(nc, nr);
L  = U{1}*U{2}';

stop_temp = zeros(2, 1);
errList   = zeros(maxIter, 1);

%%% Main loop
for k = 1: maxIter
    
    if mod(k, 50) == 0
        fprintf('S12L12: iterations = %d  beta = %d  difference=%f\n', k, beta, errList(k-1));
    end    
    beta1 = 1/beta;
    
    % Update U1 and U2
    E    = L*beta - Y3;
    U{1} = (E*U{2} + M{1}*beta + Y{1})*inv(beta*U{2}'*U{2} + (beta+lambda)*eye(ranks));
    U{2} = (E'*U{1} + M{2}*beta + Y{2})*inv((beta+lambda)*eye(ranks) + beta*U{1}'*U{1});
    
    % Update M1 and M2  
    for i = 1:2          
        [UU, sigma, VV] = svd(U{i} - Y{i}*beta1, 'econ'); 
        sigma = diag(sigma);
        svp = length(find(sigma > lambda*alpha(i)*beta1)); 
        if svp>=1
            sigma = sigma(1:svp) - lambda*alpha(i)*beta1;
        else
            svp = 1;
            sigma = 0;
        end
        M{i} = UU(:,1:svp)*diag(sigma(1:svp))*VV(:,1:svp)';
    end    
  
    % Update L 
    X = U{1}*U{2}';
    L = (X + Y3*beta1 - S + T - Y4*beta1)/2;
    
    % Update S 
    S = T - L - Y4*beta1;
    Half = 2;
    if Half == 1
        S(Omega) = ST12(S(Omega), 2*beta1);         % Half-Thresholding operator
    elseif Half == 2
        S(Omega) = solve_Lp(S(Omega), beta1, 0.5);  % Generalized Soft-Thresholding 
    end
    
    % Update Lagrange multipliers   
    for i = 1:2 
        temp = M{i} - U{i};
        Y{i} = Y{i} + beta*temp;         
        stop_temp(i) = norm(temp(:), 'fro'); 
    end
    E  = X - L;
    Y3 = Y3 + beta*E;
    Y4 = Y4 + beta*(L + S - T);
    
    stopC = max(max(stop_temp), norm(E(:), 'fro'))/normT;
    errList(k) = stopC;
 
    if stopC < tol
        break;
    else
        beta = min(beta * rho, max_beta);
    end
    
end 
errList = errList(1:k);
end

% The half-thresholding operator
function w = ST12(temp_v, gamma)
   
temp_c = 54^(1/3)*(gamma)^(2/3)/4;
temp_w = abs(temp_v) > temp_c; 
%temp_H = temp_w.*(abs(temp_v/3).^(-3/2)); 
temp_H = acos((gamma/8)*(temp_w.*(abs(temp_v/3).^(-3/2))));
temp_H = temp_w.*(1 + cos((2/3)*pi - (2/3)*temp_H));
w = (2/3)*temp_v.*temp_H;
end

% The generalized soft-thresholding operator
function  x = solve_Lp( y, lambda, p )

% Modified by Dr. Weisheng Dong 
J   = 1;
tau = (2*lambda.*(1-p))^(1/(2-p)) + p*lambda.*(2*(1-p)*lambda)^((p-1)/(2-p));
x   = zeros( size(y) );
i0  = find( abs(y) > tau );

if length(i0) >= 1
    y0 = y(i0);
    t  = abs(y0);
    for  j = 1 : J
        t = abs(y0) - p*lambda.*(t).^(p-1);
    end
    x(i0) = sign(y0).*t;
end
end


