function [X, S, errList] = S23L23_full(T, ranks, lambda, tol, maxIter, rho, beta)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%      Tractable Frobenius/Nuclear Norm Minimization for Robust PCA
% 
%
% min_{U1,Mn,L,S}: 1/3*lambda*(2*\|U1\|_{*}+\|M2\|^2_{F})+\|S_{Omega}\|^(2/3)_{2/3},
% s.t. L + S = D, L = M1M2', U1 = M1.
%       
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%Input: 
%    T:        Input data matrix of size m*n 
%    ranks:    Given rank
%    lambda:   Regularization paramter
%    tol:      Tolerance for stopping criterion
%    maxIter:  Maximum iteration number, usually 500.
%    rho:      Initial value of the parameter 
%    beta:     Penalty parameter, it should be small enough
%
%Output:
%    X : m*n   Low-rank component
%    S : m*n   Sparse component
%    errList : Difference
%
% created by Fanhua Shang on 3/6/2016, fhshang@cse.cuhk.edu.hk
%

% Default parameters
[ncr(1,1), ncr(1,2)] = size(T);
if nargin < 7
    beta = 1e-5;
end

if nargin < 6
    rho = 1.05; 
end

if nargin < 5
    maxIter = 500; 
end

if nargin < 4
    tol = 1e-4; 
end

if nargin < 3
    lambda = sqrt(max(ncr)); 
end

if nargin < 2
    ranks = guessRank(T);
end

if ranks ==-1
    ranks  = rank_estimation(T);
    lambda = lambda/1e4;
end

%%% Initialization
alpha    = [2/3, 1/3];
max_beta = 1e20;
normT    = norm(T(:)); 
%[U{1},S,U{2}] = svds(T, ranks);
%clear S  
for ii = 1:2
    U{ii} = eye(ncr(1, ii), ranks); 
end
M1 = zeros(ncr(1,1), ranks); Y1 = M1;
a1 = lansvd(T, 1, 'L'); a2 = norm(T, Inf); Y2 = T/max(a1,a2); 
clear a1 a2 
S  = sparse(ncr(1,1), ncr(1,2));
Y3 = Y2;
L  = U{1}*U{2}';
svp  = 1; rInc = 1;
stop_temp = zeros(2, 1);
errList   = zeros(maxIter, 1);

%%% Main loop
for Iter = 1: maxIter
    
    if mod(Iter, 50) == 0
        fprintf('S23L23: iterations = %d  beta = %d  difference=%f\n', Iter, beta, errList(Iter-1));
    end    
    beta1 = 1/beta;
    
    % Update U1 and U2
    E    = L*beta - Y2;
    U{1} = (E*U{2} + M1*beta + Y1)*inv((beta*U{2}'*U{2}) + (beta+(4/3)*lambda)*eye(ranks));
    U{2} = (E'*U{1})*inv(2*lambda*eye(ranks) + beta*(U{1}'*U{1}));
    
    % Update M1 
    [M1, svp] = FSVT(U{1} - Y1*beta1, lambda*alpha(1)*beta1, svp); 
    svp = min(svp+rInc, ranks);  
         
    % Update L 
    X = U{1}*U{2}';      
    L = (X + Y2*beta1 - S + T - Y3*beta1)/2;
   
    % Update S  
    Twothird = 2;
    if Twothird == 1
        S = ST23(T - L - Y3*beta1, 2*beta1);        % Twothirds-Thresholding operator
    elseif Twothird == 2
        S = solve_Lp(T - L - Y3*beta1, beta1, 2/3); % Generalized Soft-Thresholding 
    end
    
    
    % Update Lagrange multipliers 
    E = X - L;
    for i = 1:2 
        if i < 2
            temp1 = M1 - U{i};           
            Y1    = Y1 + temp1*beta;                       
            stop_temp(i) = norm(temp1(:), 'fro');
        else
            Y2 = Y2 + E*beta;
            stop_temp(i) = norm(E(:), 'fro');
        end
    end   
    Y3 = Y3 + (L + S - T)*beta;
    
    stopC = max(stop_temp)/normT;
    errList(Iter) = stopC;
 
    if stopC < tol
        break;
    else
        beta = min(beta * rho, max_beta);
    end
    
end 
errList = errList(1:Iter);
end

% The twothirds-thresholding operator
function w = ST23(temp_v, beta)

temp_p = 2*(3*beta^3)^0.25/3;

temp_w = abs(temp_v) > temp_p;
temp_w = sign(temp_v).*temp_w;
pp = acosh((27*temp_v.^2)/16*beta^(-3/2));
pp = 2/sqrt(3)*beta^(0.25)*(cosh(pp/3).^(0.5));
w  = temp_w.*((pp + sqrt(2*abs(temp_v)./pp - pp.^2))/2).^3;    
end


% The generalized soft-thresholding operator
function  x = solve_Lp( y, lambda, p )

% Modified by Dr. Weisheng Dong 
J   = 1;
tau = (2*lambda.*(1-p))^(1/(2-p)) + p*lambda.*(2*(1-p)*lambda)^((p-1)/(2-p));
x   = zeros( size(y) );
i0  = find( abs(y) > tau );

if length(i0) >= 1
    y0 = y(i0);
    t  = abs(y0);
    for  j = 1 : J
        t = abs(y0) - p*lambda.*(t).^(p-1);
    end
    x(i0) = sign(y0).*t;
end
end
