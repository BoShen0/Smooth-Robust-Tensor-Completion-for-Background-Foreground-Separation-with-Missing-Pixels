function [Z, L, M] = Unifying(X, W, rank_est, lambda, rho, tol, maxIter, DEBUG)
% 
%------------------------------
% Model for Robust RPCA (RPCA)
% min  |W.*(X-Z)|_{1} + lambda/2*(|L|^{2}_{F}+|M|^{2}_{F}),
% s.t., Z = LM .
%
%--------------------------------
%Input: 
%   X:        Input data matrix of size m*n 
%   W:        Indicator matrix of size m*n, with '1' means 'observed', and '0' 'missing'.
%   lambda:   Regularization paramter
%   rank_est: Estimation rank
%   rho:      Increasing ratio of the penalty parameter mu, usually 1.2.
%   tol:      Tolerance for stopping criterion
%   maxIter:  Maximum iteration number, usually 1000.
%
%Output:
%   Z: m*n  low-rank component, such that Z = L*M.
%   L : m*d  dictionart matrix
%   M : d*n  data reprensetaion matrix
%
% created by Fanhua Shang on 9/1/2014, fhshang@cse.cuhk.edu.hk.

% Default parameters

[m, n] = size(X);
WC = logical(1-double(W));

if (~exist('DEBUG','var'))
    DEBUG = 1;
end

if nargin < 7
    maxIter = 1000; 
end

if nargin < 6
    tol = 1e-4; 
end

if nargin < 5
    rho = 1.05; 
end

if nargin < 4
    rank_est = round(1.2*rank_estimation(X));
end

if nargin < 3
    lambda = sqrt(max(m, n));
end
if nargin < 2
    disp('Please input the observation X, the indicator W, and try again.');
end

% Parameter set
max_mu = 1e20;
mu     = 1e-3;
    
% Initializing optimization variables
% norm_two = lansvd(X, 1, 'L');
% norm_inf  = lambda*norm(X(:), inf);
% norm_dual = max(norm_two, norm_inf);
normX = norm(X, 'fro');
Y  = zeros(m, n);
Z  = X;
M  = rand(n, rank_est);
%LM_pre =zeros(m, n);

% Start main loop
iter = 0;
while iter < maxIter
    iter = iter + 1;   
    for jj = 1:1
        % Update L  
        L = (mu*Z + Y)*M*inv(mu*M'*M + lambda*eye(rank_est));
    
        % Update M
        M = (mu*Z + Y)'*L*inv(mu*L'*L + lambda*eye(rank_est));
     
        % Update Z 
        LM    = L*M';
        temp  = X - LM + Y/mu; 
        temp  = max(0, temp - 1/mu) + min(0, temp + 1/mu);
        Z(W)  = X(W)- temp(W);
        temp  = LM - Y/mu; 
        Z(WC) = temp(WC);
    end
    % Stopping criteria      
    dY = Z -LM;
    stopC = norm(dY, 'fro');
   
    if DEBUG
         if iter==1 || mod(iter,50)==0 || stopC<tol
             disp(['iter ' num2str(iter) ',mu=' num2str(mu,'%2.1e') ...
            ',recErr=' num2str(stopC,'%2.3e')]);
         end
    end 
    
    if stopC < tol 
        
       break;
       
    else
        % Update Y
        Y = Y + mu*dY;
        mu = min(max_mu, mu*rho);
        %LM_pre = LM;
    end
    
end

         
% This Function to Estimate the Rank of the Input Matrix
function d = rank_estimation(X)
	
[n m] = size(X);
epsilon = nnz(X)/sqrt(m*n);
mm = min(100, min(m, n));
S0 = lansvd(X, mm, 'L');

S1 = S0(1:end-1)-S0(2:end);
S1_ = S1./mean(S1(end-10:end));
r1 = 0;
lam = 0.05;
while(r1 <= 0)
    for idx = 1:length(S1_)
        cost(idx) = lam*max(S1_(idx:end)) + idx;
    end
    [v2 i2] = min(cost);
    r1 = 2*max(i2-1);
    lam = lam+0.05;
end
clear cost;

for idx = 1:length(S0)-1
    cost(idx) = (S0(idx+1)+sqrt(idx*epsilon)*S0(1)/epsilon )/S0(idx);
end
[v2 i2] = min(cost);
r2 = 2*max(i2);

d = max([r1 r2]);
