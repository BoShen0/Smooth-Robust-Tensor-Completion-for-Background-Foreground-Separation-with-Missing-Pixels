function [L, E, OptMean] = test_MCOS(para,lambda)%  (M,m,n,Omega,k,num)

% parameters

M = para.X;
W = para.W;
r = para.r;
size = para.size;
m = size(1);
n = size(2);
Omega = para.Omega;
data = para.data;
Test_ind = para.test.Ind;
Test_values = para.test.values;
dif = para.dif;

% parameters for algorithm
% test algorithms
[out] = MCOS(M,W,r,500,lambda);
L = out.U*out.V';
num = para.out_num;
L = L(:,1:n-num);
E = out.E;
OptMean = out.b*ones(1,n);
E = E(:,1:n-num);