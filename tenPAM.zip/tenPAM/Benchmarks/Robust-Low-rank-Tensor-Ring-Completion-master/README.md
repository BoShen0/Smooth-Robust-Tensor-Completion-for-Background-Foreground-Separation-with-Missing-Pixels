# Robust-Low-rank-Tensor-Ring-Completion
If you have used the code or datasets in this paper, please cite:

@ARTICLE{9136899,  
author={H. {Huang} and Y. {Liu} and Z. {Long} and C. {Zhu}},  
journal={IEEE Transactions on Computational Imaging},   
title={Robust Low-Rank Tensor Ring Completion},   
year={2020},  
volume={6},  
number={},  
pages={1117-1126},  
doi={10.1109/TCI.2020.3006718}
}
