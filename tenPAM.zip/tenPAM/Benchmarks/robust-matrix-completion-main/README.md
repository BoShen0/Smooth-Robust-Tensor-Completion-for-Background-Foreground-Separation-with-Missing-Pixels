# robust-matrix-completion
This is the matlab code of the paper:

He, Yicong, Fei Wang, Yingsong Li, Jing Qin, and Badong Chen. "Robust matrix completion via maximum correntropy criterion and half-quadratic optimization." IEEE Transactions on Signal Processing 68 (2019): 181-195.
