# robust-tensor-completion

This is the code of the paper:

Yicong He, George K. Atia, "Robust Low-tubal-rank Tensor Completion based on Tensor Factorization and Maximum Correntopy Criterion", https://arxiv.org/abs/2010.11740

The test data are generated from Densely Annotated VIdeo Segmentation (DAVIS) 2016,  https://davischallenge.org/davis2016/code.html
