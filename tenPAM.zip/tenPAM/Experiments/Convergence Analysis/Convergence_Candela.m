clc, clear classes, close all;

%% load data to use
imagefiles = dir('*.png');      
nfiles = length(imagefiles);    % Number of files found
for ii=1:nfiles
   currentfilename = imagefiles(ii).name;
   currentimage = imread(currentfilename);
   figure(1), imshow(currentimage)
   images(:,:,ii) = rgb2gray(currentimage);
end
images = double(images);

GT_background = double(rgb2gray(imread('GT_Background1.png')));
imshow(GT_background/255)

%% Convergence Analysis
RatioSet = flip(0.1:0.2:0.9);
for Iter_out = 1:5
Nframes = 20;
D = images(:,:,1:Nframes);
sizeD = size(D);
D2 = D;
sizeD2 = size(D2);

%%%% Input Missing vaules
ObservedRatio = RatioSet(Iter_out);
Nelement = prod(sizeD);
% Omega = zeros(Nelement,1);
rng(0,'twister');
indexSet = randperm(Nelement);
Omega = indexSet(1:floor(Nelement * ObservedRatio));
Omega_remain = indexSet;
Omega_remain(1:floor(Nelement * ObservedRatio))=[];

D_temp = D2(:);
b = D_temp(Omega);

%%%% create groundtruth background
for sss = 1:sizeD(3)
trX1(:,:,sss) = GT_background;
end
trX1_2 = trX1;

%%  Our proposed method
% rng(1,'twister');
% OurSet = 3*lhsdesign(1,SearchSize) + 0.02;  % set from 0.2 ~ 0.8; now update 0~3

[height, width,  nfrm] = size(D2);

clear opts;
opts.maxIter    = 50;
opts.tol        = 1e-6;
opts.trX0       = D2;
opts.trX1       = trX1_2;

beta = ones(3,1)*1e+0/mean(abs(opts.trX0(:))); beta(2) = 4e-1/mean(abs(opts.trX0(:)));
opts.beta = beta;  % maxIter = 100, 1e+1,4e-1, lam1 = 0.55;
tucker_rk = [200, 200,1];
rk1       = tucker_rk;   
lam1      = 0.5;

tic
[tenX0, tenX1, tenX2, tenOut] = FgBgLrApprTVFastTCnew_Obj(Omega, b, sizeD, rk1, lam1, opts);
toc

ConvergenceResult{Iter_out} = [tenOut.objValuePath;
tenOut.relChgX0Path';
tenOut.relChgX1Path';
tenOut.relChgX2Path';
tenOut.relErrX0Path';
tenOut.relErrX1Path';
tenOut.relChgU1Path;
tenOut.relChgU2Path;
tenOut.relChgU3Path];
end
it = 5;
YMatrix1 = [ConvergenceResult{1}(it,:)', ConvergenceResult{2}(it,:)', ConvergenceResult{3}(it,:)',...
    ConvergenceResult{4}(it,:)',ConvergenceResult{5}(it,:)'];

%% Sensitivity
Nframes = 20;
D = images(:,:,1:Nframes);
sizeD = size(D);
D2 = D;
sizeD2 = size(D2);

%%%% Input Missing vaules
ObservedRatio = 0.5;
Nelement = prod(sizeD);
% Omega = zeros(Nelement,1);
rng(0,'twister');
indexSet = randperm(Nelement);
Omega = indexSet(1:floor(Nelement * ObservedRatio));
Omega_remain = indexSet;
Omega_remain(1:floor(Nelement * ObservedRatio))=[];

D_temp = D2(:);
b = D_temp(Omega);

%%%% create groundtruth background
for sss = 1:sizeD(3)
trX1(:,:,sss) = GT_background;
end
trX1_2 = trX1;

%%  Our proposed method
% rng(1,'twister');
% OurSet = 3*lhsdesign(1,SearchSize) + 0.02;  % set from 0.2 ~ 0.8; now update 0~3

[height, width,  nfrm] = size(D2);

clear opts;
opts.maxIter    = 50;
opts.tol        = 1e-6;
opts.trX0       = D2;
opts.trX1       = trX1_2;

% beta = ones(3,1)*1e+1/mean(abs(opts.trX0(:))); beta(2) = 4e-1/mean(abs(opts.trX0(:)));
% opts.beta = beta;  % maxIter = 100, 1e+1,4e-1, lam1 = 0.55;
tucker_rk = [256, 384,1];
rk1       = tucker_rk;   
LambdaSet = [0.01, 0.05:0.05:1 1.2:0.2:3];

for ii=1:size(LambdaSet,2)
lam1      = LambdaSet(ii);

tic
[tenX0, tenX1, tenX2, tenOut] = FgBgLrApprTVFastTCnew1(Omega, b, sizeD, rk1, lam1, opts);
toc

SensitivityResult{ii} = [tenOut.relErrX0Path';
tenOut.relErrX1Path'];
end
for ii=1:size(LambdaSet,2)
    AA = SensitivityResult{ii};
    BB(ii) = AA(2,end);
end

plot(SensitivityResult{1}(2,:))