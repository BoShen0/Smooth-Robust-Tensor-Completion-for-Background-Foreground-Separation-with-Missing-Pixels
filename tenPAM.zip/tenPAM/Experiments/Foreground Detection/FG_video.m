%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% this is for numerical study for robust tensor completion; first
% author: Bo Shen, email: boshen@vt.edu; the objective of this numerical
% study is to extract the foreground of incomplete video
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc, clear classes, close all;

%% load data to use
imagefiles = dir('*.jpg');      
nfiles = length(imagefiles);    % Number of files found
for ii=1:nfiles
   currentfilename = imagefiles(ii).name;
   currentimage = imread(currentfilename);
%    figure(1), imshow(currentimage)
   images(:,:,ii) = rgb2gray(currentimage);
end

images = double(images);

imagefiles2 = dir('*.png');      
nfiles2 = length(imagefiles2);    % Number of files found
for ii=1:nfiles2
   currentfilename = imagefiles2(ii).name;
   currentimage = imread(currentfilename);
%    figure(1), imshow(currentimage)
   GTimages(:,:,ii) = double(currentimage);
end
GTimages = double(GTimages > 0.5);

imagesNew   = images(:,:,851:950);
GTimagesNew = GTimages(:,:,851:950);

RatioSet = flip(0.1:0.2:0.9);

for Iter_out = 1:5
Nframes = 80;
D = imagesNew(:,:,1:Nframes);
trX1_2 = GTimagesNew(:,:,1:Nframes);
sizeD = size(D);
D2 = D;
sizeD2 = size(D2);

%%%% Input Missing vaules
ObservedRatio = RatioSet(Iter_out);  % (1-ObservedRatio) is the ratio of missing values
Nelement = prod(sizeD);
% Omega = zeros(Nelement,1);
rng(0,'twister');
indexSet = randperm(Nelement);
% index set of the observerd pixels
Omega = indexSet(1:floor(Nelement * ObservedRatio));
Omega_remain = indexSet;
Omega_remain(1:floor(Nelement * ObservedRatio))=[];

D_temp = D2(:);
b = D_temp(Omega);

%%%% create groundtruth background

% displayVideo(D);

% clear the data
clear OurResult MCOSResult BFMNMResult HQ_ASDResult RTRCResult HQ_TCASDResult
clear FinalResult FinalTimeResult
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% start to run the main code
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
SearchSize = 10;
random_number = 0;   % to add more randomness; used to be 0 for the first 4 case
%%  Our proposed method
rng(1,'twister');
OurSet = 3*lhsdesign(1,SearchSize) + 0.02;  % set from 0.2 ~ 0.8; now update 0~3

for iter = 1:SearchSize
fprintf('Proposed Method %i \n',iter);

[height, width,  nfrm] = size(D2);

clear opts;
opts.maxIter    = 100;
opts.tol        = 1e-6;
opts.trX0       = D2;
% opts.GTX0       = D(:,:,1:80);
opts.trX1       = trX1_2;

beta = ones(3,1)*1e+1/mean(abs(opts.trX0(:))); beta(2) = 4e-1/mean(abs(opts.trX0(:)));
opts.beta = beta;  % maxIter = 100, 1e+1,4e-1, lam1 = 0.55;
tucker_rk = [ceil(height*0.99), ceil(width*0.99),1];
rk1       = tucker_rk;   
lam1      = OurSet(iter);

tic
[tenX0, tenX1, tenX2, tenOut] = FgBgLrApprTVFastTCnew1(Omega, b, sizeD, rk1, lam1, opts);
Time(iter) = toc;

[Fscore, Precision,Recall, ~]  = videoFGEval(trX1_2, tenX2, sizeD2,5000);
% avePSNR1        = mean(PSNR1)
% aveSSIM1        = mean(SSIM1)
OurResult(:,:,iter) = [Precision;Recall;Fscore];
end
FinalResult{1} = OurResult;
FinalTimeResult{1} = Time;


%% MCOS (2021 Information Science)
%%%%  Matrix completion with column outliers and sparse noise
clear para Time
D_temp2 = D2(:);
D_temp2(Omega_remain)=0;
[height, width,  nfrm] = size(D2);

M0 = reshape(D2(:),[height * width, Nframes]);
M  = reshape(D_temp2,[height * width, Nframes]);

[m,n]=size(M);
M_train = sparse(M);
Omega2  = find(M_train);   % 
data = M_train(Omega2); 

num = 0;
para.out_num = num;
if num>0   % have outliers, test only inliers
    temp = M - M_train;
    Test_ind = find(temp(:,1:n-num));
    para.test.Ind = Test_ind;
    Tdata = M(:,1:n-num);
    para.test.values = Tdata(Test_ind);   % Test values
else
    Test_ind = find(M - M_train);      % Test ID
    para.test.Ind = Test_ind;
    para.test.values = M(Test_ind);     % Test values
end

[I,J] = ind2sub([m,n],Omega2); 
W = sparse(I,J,ones(length(Omega2),1),m,n,length(Omega2));

para.Omega = Omega2;
para.size = [m,n];
para.data = data;
para.X = M_train;
para.r = 10;
para.W = W;
para.M0 = M0;
para.dif = max(data)-min(data);

rng(2+6*random_number,'twister');
MCOSSet = 3*lhsdesign(1,SearchSize) + 0.01;  % set from 0 ~ 3
for iter = 1:SearchSize
lambda = MCOSSet(iter);  %lambda is a parameter that needs to be tunned, such as 0.12 for data matrix with sparse noise. If there is no sparse noise, a large lambda will be better, like 1.5

tic
[S_MCOS,~,L_MCOS] = test_MCOS(para,lambda);  
Time(iter) = toc;

[Fscore, Precision,Recall, ~]  = videoFGEval(trX1_2, S_MCOS, sizeD2,5000);
% avePSNR1        = mean(PSNR1)
% aveSSIM1        = mean(SSIM2)
MCOSResult(:,:,iter) = [Precision;Recall;Fscore];
end
FinalResult{2} = MCOSResult;
FinalTimeResult{2} = Time;

%% BFMNM(2018 PAMI paper) 
%%%% Bilinear Factor Matrix Norm Minimization for Robust PCA: Algorithms and Applications
clear Time
D_temp3 = D2(:);
D_temp3(Omega_remain)=0;
[height, width,  nfrm] = size(D2);
M  = reshape(D_temp3,[height * width, Nframes]);
D = M;
W = D>0;
[m,n]=size(D);
Grank = 2;

rng(3+6*random_number,'twister');
BFMNMSet = 200*lhsdesign(1,SearchSize) + 5;  % set from 5 ~ 205

for iter = 1:SearchSize
%%% Our (S+L)2/3 Method
lambda = sqrt(max(m, n))/BFMNMSet(iter);
% tic
% [L_BFMNM, S_BFMNM, ~] = inexact_alm_WNNM_MC(D, W,sqrt(2*m*n), eps, 1e-4, -1);
% toc
tic
[L_BFMNM, S_BFMNM] = S23L23(D, W, Grank, lambda);
Time(iter) = toc;

[Fscore, Precision,Recall, ~]  = videoFGEval(trX1_2, S_BFMNM, sizeD2,5000);
% avePSNR1        = mean(PSNR1)
% aveSSIM1        = mean(SSIM2)
BFMNMResult(:,:,iter) = [Precision;Recall;Fscore];
end
FinalResult{3} = BFMNMResult;
FinalTimeResult{3} = Time;

%%  HQ-ASD (2020 IEEE-Signal Processing)
%%%% Robust Matrix Completion via Maximum Correntropy Criterion and Half-Quadratic Optimization
clear Time
D_temp4 = D2(:);
D_temp4(Omega_remain)=0;
[height, width,  nfrm] = size(D2);
MissM  = reshape(D_temp4,[height * width, Nframes]);
Mask = MissM>0;

[n1,n2]=size(MissM);
r=1;

option.U=abs(0.001*rand(n1,r));
option.V=abs(0.001*rand(r,n2));
option.yita=2;
option.sigmamin=0.01;
option.maxitr=500;

option.stop_1=1e6;
option.stop_2=1e-7;

rng(4+6*random_number,'twister');
HQ_ASDSet = 2*lhsdesign(1,SearchSize) + 1;  % set from 1 ~ 3

for iter = 1:SearchSize
option.yita=HQ_ASDSet(iter);

tic
L_HQ_ASD=HQ_ASD(MissM,Mask,option);
Time(iter) = toc;
S_HQ_ASD = MissM - L_HQ_ASD;
S_HQ_ASD(~Mask) = 0;
[Fscore, Precision,Recall, ~]  = videoFGEval(trX1_2, S_HQ_ASD, sizeD2,5000);
% avePSNR1        = mean(PSNR1)
% aveSSIM1        = mean(SSIM2)
HQ_ASDResult(:,:,iter) = [Precision;Recall;Fscore];
end
FinalResult{4} = HQ_ASDResult;
FinalTimeResult{4} = Time;

%% RTRC (IEEE TRANSACTIONS ON COMPUTATIONAL IMAGING, VOL. 6, 2020)
%%%% Robust Low-Rank Tensor Ring Completion
clear Time
D_temp5 = D2(:);
D_temp5(Omega_remain)=0;
vid_noise = reshape(D_temp5,sizeD2);
P = vid_noise>0;

rng(5+6*random_number,'twister');
RTRCSet = 2*lhsdesign(1,SearchSize) + 3;  % set from 3 ~ 5

for iter = 1:SearchSize
    tic
[L_RTRC,S_RTRC,z,~]=RTRC(vid_noise,P,10^-RTRCSet(iter),false);%4.4-4.6
    Time(iter) = toc;
    
[Fscore, Precision,Recall, ~]  = videoFGEval(trX1_2, S_RTRC, sizeD2,5000);
% avePSNR1        = mean(PSNR1)
% aveSSIM1        = mean(SSIM2)
RTRCResult(:,:,iter) = [Precision;Recall;Fscore];
end
FinalResult{5} = RTRCResult;
FinalTimeResult{5} = Time;

%% HQ-TCASD (Arxiv 2020)
%%%% Robust Low-tubal-rank Tensor Completion based on Tensor Factorization 
%%%% and Maximum Correntopy Criterion
clear Time
D_temp6 = D2(:);
D_temp6(Omega_remain)=0;
MissM  = reshape(D_temp6,size(D2));
Mask = MissM>0;

[n1,n2,n3]=size(MissM);
option=[];

option.debug    = 0;
option.maxitr   = 500;
option.stopc    = 1e-5;

% HQ method
option.sigmamin = 0.15;
option.qtmin    = 0.1;
option.yita     = 10;

% rank
option.rank     = 100;

option.stopc  = 1e-5;
option.stopc2 = 1e-5;
option.lambda = 0.2;

rng(6+6*random_number,'twister');
HQ_TCASDSet = 0.5*lhsdesign(1,SearchSize) + 0.1;  % set from 0.1 ~ 0.6

for iter = 1:SearchSize
 option.lambda = HQ_TCASDSet(iter);
 tic
L_HQ_TCASD = HQ_TCASD(MissM,Mask,D2,option);
 Time(iter) = toc;

S_HQ_TCASD = MissM - L_HQ_TCASD;
S_HQ_TCASD(~Mask) = 0;

[Fscore, Precision,Recall, ~]  = videoFGEval(trX1_2, S_HQ_TCASD, sizeD2,5000);
% avePSNR1        = mean(Fscore)
% aveSSIM1        = mean(Recall)
HQ_TCASDResult(:,:,iter) = [Precision;Recall;Fscore];
end

FinalResult{6} = HQ_TCASDResult;
FinalTimeResult{6} = Time;
%%%%% save data to local
save(strcat('Pedestrians_',num2str(100-100*ObservedRatio),'%.mat'), 'FinalResult', 'FinalTimeResult'); 
end
%% Conclude final results for the table
clear DD AAfinal AARunTime
for jj = 1:6
    clear AA BB CC
AA = FinalResult{jj};
   for ii = 1:size(AA,3)
   BB(ii) = mean(AA(3,:,ii));
   CC(ii,:) = mean(AA(:,:,ii),2);
   end
[MaxValue,MaxIndex] = max(BB);
DD(:,jj) = CC(MaxIndex,:)';
EE(jj) = mean(FinalTimeResult{jj});
end

AAfinal(:,1:5) = DD(:,2:6);
AAfinal(:,6) = DD(:,1);
AARunTime(1:5) = EE(2:6);
AARunTime(6) = EE(1);

%% Plot F-measure versus the number of frames
% clear all
for jj = 1:6
   clear AA BB CC
AA = FinalResult{jj};
   for ii = 1:size(AA,3)
   BB(ii) = mean(AA(3,:,ii));
   CC(ii,:) = mean(AA(:,:,ii),2);
   end
[MaxValue,MaxIndex] = max(BB);
FF(:,jj) = AA(3,:,MaxIndex)';
end

