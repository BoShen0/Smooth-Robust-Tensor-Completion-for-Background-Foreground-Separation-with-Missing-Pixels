Note this package is only used for academically reproductive research.
Any commercial use will be forbidden.

This package used the following tensor toolbox. 
If you use this package, please cite this webpage and related papers:
Brett W. Bader, Tamara G. Kolda and others. 
MATLAB Tensor Toolbox Version 2.6, Available online, February 2015.
URL: http://www.sandia.gov/~tgkolda/TensorToolbox/.


1. runme_first   -  for mexing the c++ script

2. demo_realData  - for conducting the proposed tensor robust
PCA approach on the real video data.



