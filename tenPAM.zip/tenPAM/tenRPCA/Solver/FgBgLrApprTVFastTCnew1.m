function [x0, x1, x2, out] = FgBgLrApprTVFastTCnew1(Omega, y, sizeD, rk, lam, opts)
%-----------------------------------------------------------------------------------------------------
% Model: min  fai(E) + lam*(||DX2||_{l1})
%        s.t.  y = A*(x0), x0 = L + E + X2. 
% where X1 = [G; U1, U2 U3] + E, L = [G;U1,U2,U3], fai(E) = 0.5*|| E ||^2 or ||E||_1
%
% Equivalent Model: min fai(E) + lam*(||p1||_{TV})
%        s.t.  p1= Dx2,  
%              y = A*(x0),  x0 = L + E + X2.  
% where X1 = [G; U1, U2 U3] + E.
% 
%--------------------------------INPUTs----------------------------------------------------------
% A: measurement operator
% y: measurement signal
% sizeD : size of original tensor data 
% rk : the rank of L
% lam: traded-off parameter
% opts:
%  - maxIter
%  - tol
%  - beta
%  - init_x0
%  - init_x2
%  - trX0 (ground truth X0)
%  - trX1 (ground truth X1)
%  - trX2 (ground truth X2)
%  - cont: use continuation (true) or not (false).
%  - contpar: continuation parameter (<1).
%  - contfactor: continuatoin factor (>1).
%---------------------------------OUTPUTs-------------------------------------------------
% x1 : background
% x2 : foreground
% x0:  reconstructed video
% nois: the disturbance term to the ideal video background L
% out: 
%  - time
%  - iter
%  - rsnrPath
%  - relChgX1Path
%  - relChgX2Path
%  - relErrX0Path
%  - relErrX1Path
%  - relErrX2Path
% ------------------------------------------------------------------------------------------
%  contact: caowenf2006@163.com,  yao.s.wang@gmail.com
%  Authors: W.F. Cao and Y. Wang 
%  2015 - 7 - 7 , @ XJTU
%

%%  check and initilization
if ~exist('opts','var'); opts=[]; end
if isfield(opts,'maxIter'); maxIter = opts.maxIter; else maxIter = 250; end
if isfield(opts,'tol');  tol = opts.tol; else tol = 1e-6; end;
if isfield(opts,'beta'); beta = opts.beta; else beta = ones(3,1)*1e-5/mean(abs(y(:))); end
if isfield(opts,'gauss_frag'); gauss_frag = opts.gauss_frag; else gauss_frag = 1; end;
if isfield(opts,'trX0');   trX0 = opts.trX0; end;
if isfield(opts,'trX1');   trX1 = opts.trX1; end;
if isfield(opts,'trX2');   trX2 = opts.trX2; end;
if isfield(opts,'isCont')
    isCont = opts.isCont; contpar = opts.contpar; contfactor = opts.contfactor;
 else
    isCont = true; contpar = 0.95; contfactor = 1.15;
end
disp(opts);

% init. variables 
N    = prod(sizeD);
h    = sizeD(1);
w    = sizeD(2);
d    = sizeD(3);

x0    = zeros(N,1);
x2    = zeros(N,1);
nois  = zeros(N,1);
p1    = zeros(3*N, 1);
v1    = zeros(3*N, 1);
v2    = zeros(N,1);
% v3    = zeros(size(y));

% for low rank appr.
dimRank    = numel(rk);
if dimRank == 1
    Atb        = A'*y;
    Atb_mat    = reshape(Atb,h*w,d);
    [U,Sig,V]  = MySVD(Atb_mat);
    U          = U(:,1:rk);
    V          = (V(:,1:rk))';
    Lr        = U*Sig(1:rk,1:rk)*V;
    Lr        = Lr(:);
else
    Avector        = zeros(N,1);
    Avector(Omega) = y;
    OmegaC = 1:N;
    OmegaC(Omega)= [];
    Avector(OmegaC) = NaN; 
    Aarray         = reshape(Avector,sizeD);
    Atb_ten        = fillmissing(Aarray,'movmean',10); 
    Atb_ten        = fillmissing(Atb_ten,'linear');
%     displayVideo(Atb_ten)
    Ten      = tucker_als(tensor(Atb_ten),rk,'tol',1e-6,'printitn',0);
    Lr       = double(Ten);
    Lr       = Lr(:);
end

x1   = Lr;

Eny_x   = ( abs(psf2otf([+1; -1], [h,w,d])) ).^2  ;
Eny_y   = ( abs(psf2otf([+1, -1], [h,w,d])) ).^2  ;
Eny_z   = ( abs(psf2otf([+1, -1], [w,d,h])) ).^2  ;
Eny_z   =  permute(Eny_z, [3, 1 2]);
denom1  =  Eny_x + Eny_y + Eny_z;

%% main loop
relErrX0Path = zeros(maxIter, 1);
relErrX1Path = zeros(maxIter, 1);
relErrX2Path = zeros(maxIter, 1);
rsnrPath     = zeros(maxIter, 1);
relChgX0Path = zeros(maxIter, 1);
relChgX1Path = zeros(maxIter, 1);
relChgX2Path = zeros(maxIter, 1);
stopPath     = zeros(maxIter, 1);
gamma    = 1.15;
display  = 1;
tic;
for iter = 1 : maxIter
    
    fprintf('\n*****************************iter: %d ******************************\n', iter');
    
    x0_pre = x0; x1_pre = x1; x2_pre = x2;
    
    %- x0 subproblem
%     temp_x0  = v2 + beta(2)*(Lr + nois + x2) + A'*(beta(3)*y - v3);
%     temp_x0  = temp_x0 / beta(2);
%     x0  = temp_x0 - (  beta(3)/(beta(2)+beta(3)) )*( A'*(A*temp_x0) );
%     Ax0 = A*x0;
	  x0  = Lr + x2+ v2/beta(2);
      temp_y = x0(Omega);
      x0(Omega) = y;
    %- x1 Lr= ([G;U1,U2,U3]) - subproblem
    temp_x1 = x0 - x2- v2/beta(2);
    if dimRank == 1 %% low rank matarix
        
        temp_x1 = reshape(temp_x1, h*w, d);
        for i_u =  1 : 2
         U = temp_x1 * V';
         V = pinv(U) * temp_x1;
        end
        Lr = U*V;
        Lr = Lr(:);
    else %% low tensor
        
        temp_x1 = reshape(temp_x1, sizeD);
        Lr  = double( tucker_als(tensor(temp_x1), rk, 'tol',1e-6,'printitn',0) );
        Lr  = Lr(:);
    end
  
    x1   = Lr;
    
    %- E subproblem
%     if  gauss_frag
%          nois = beta(2)*( x0 - Lr - x2 - v2/beta(2) ) / (beta(2) + 1);
%     else
%          nois = softThres( x0 - Lr - x2 - v2/beta(2), 1/beta(2) );
%     end
%     
    %- x2 subproblem
    temp_x2  = x0 - Lr;
    diffT_p1 = diffT3( beta(1)*p1 - v1, sizeD );
    numer1   = reshape( diffT_p1 + beta(2)*temp_x2 - v2, sizeD);
    x2  = real( ifftn( fftn(numer1) ./ (beta(1)*denom1 + beta(2)) ) );
    x2  = x2(:);
    
    
    %- p1 subproblem
    diff_x2 = diff3(x2, sizeD); 
    p1      = softThres( diff_x2 + v1/beta(1), lam/beta(1) );
     

    %- updating multipliers
	v1 = v1 - gamma*beta(1)*(p1 - diff_x2);
 	v2 = v2 - gamma*beta(2)*(x0 - Lr - x2);
% 	v3 = v3 - gamma*beta(3)*(y - Ax0);
    
    %- terminating the algorithm and saving some ralted information
    if exist('trX0', 'var')
        relErrX0Path (iter) = norm(x0 - trX0(:))/ norm(trX0(:));
        if display
            fprintf('relErrX0: %4.4f \n', relErrX0Path (iter));
        end
    end
    
    if exist('trX1','var')
        relErrX1Path (iter) = norm(x1 - trX1(:)) / norm(trX1(:));
        if display
            fprintf('relErrX1: %4.4f \n', relErrX1Path (iter));
        end
    end
    
    if exist('trX2','var')
        relErrX2Path (iter) = norm(x2 - trX2(:)) / norm(trX2(:));
        if display
            fprintf('relErrX2: %4.4f \n', relErrX2Path (iter));
        end
    end
    
    if exist('trX0','var')
         tem = trX0(:);
         rsnrPath(iter) = SNR(  x0(h*w +1 : (N-h*w) ) , tem(h*w+1 :  (N-h*w) ) );
        if display
            fprintf('rsnr: %4.4f\n', rsnrPath(iter));
        end
     end
    
    relChgX0 = norm(x0 - x0_pre,'fro')/max(1,norm(x0_pre,'fro'));
    relChgX1 = norm(x1 - x1_pre,'fro')/max(1,norm(x1_pre,'fro'));
    relChgX2 = norm(x2 - x2_pre,'fro')/max(1,norm(x2_pre,'fro'));
    relChgX0Path(iter) = relChgX0;
    relChgX1Path(iter) = relChgX1;
    relChgX2Path(iter) = relChgX2;
	if  display
        fprintf('relChgX0:%4.4e,     relChgX1: %4.4e \n              relChgX2: %4.4e\n', relChgX0, relChgX1,relChgX2);
    end
    
    stopCond = norm(temp_y - y)/norm(y);
    stopPath(iter) = stopCond;
    fprintf('stopFormulaVal: %4.4e \n', stopCond);
    if (iter> 50) &&  (stopCond < tol ) 
          disp(' !!!stopped by termination rule!!! ');  break;
    end
    
    %- continuation
      if  isCont
            nr1 = norm(p1 - diff_x2, 'fro');
            nr2 = norm(x0 - Lr - x2, 'fro');
            nr3 = norm(y - temp_y, 'fro');

            if iter >1 && nr1 > contpar * nr1_pre
                beta(1) = contfactor*beta(1);
            end
            if iter>1 && nr2 > contpar * nr2_pre
                beta(2) = contfactor*beta(2);
            end
            if iter>1 && nr3 > contpar * nr3_pre
                beta(3) = contfactor*beta(3);
            end
           
            if display
                
               fprintf('nr1(p1-diff_x2): %4.4e, nr2(x0-Lr-x2): %4.4e\n              nr3(y-temp_y): %4.4e\n',nr1,nr2,nr3);
            end
      
            nr1_pre =nr1;    nr2_pre = nr2;    nr3_pre = nr3;
      end    
     
%     %- should remove 
%     x0 = x0 - x2;
%     x2    = zeros(N,1);
end


%% ouput
out.time     = toc;
out.iter     = iter;
out.stopPath = stopPath(1:iter);
% out.nois     = nois;
out.p1       = p1; 
out.relChgX0Path = relChgX0Path(1:iter);
out.relChgX1Path = relChgX1Path(1:iter);
out.relChgX2Path = relChgX2Path(1:iter);

if exist('trX0','var')
    out.rsnrPath = rsnrPath(1:iter);
    out.relErrX0Path = relErrX0Path(1:iter) ;
end
if exist('trX1','var')
     out.relErrX1Path = relErrX1Path(1:iter) ;
end
if exist('trX2','var')
     out.relErrX2Path = relErrX2Path(1:iter) ;
end

return;

end


%%  subFunctions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% compute the diff. of one 3-order tensor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function diff_x = diff3(x,  sizeD)

tenX   = reshape(x, sizeD);

dfx1     = diff(tenX, 1, 1);
dfy1     = diff(tenX, 1, 2);
dfz1     = diff(tenX, 1, 3);

dfx      = zeros(sizeD);
dfy      = zeros(sizeD);
dfz      = zeros(sizeD);
dfx(1:end-1,:,:) = dfx1;
dfx(end,:,:)     =  tenX(1,:,:) - tenX(end,:,:);
dfy(:,1:end-1,:) = dfy1;
dfy(:,end,:)     = tenX(:,1,:) - tenX(:,end,:);
dfz(:,:,1:end-1) = dfz1;
dfz(:,:,end)     = tenX(:,:,1) - tenX(:,:,end);

diff_x = [dfx(:); dfy(:); dfz(:)];
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  compute the inverse-diff. of one 3-order tensor (3*N)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function diffT_a = diffT3(a, sizeD)

N    = prod(sizeD);
tenX = reshape(a(1: N), sizeD);
tenY = reshape(a((N+1):2*N), sizeD);
tenZ = reshape(a((2*N+1):3*N), sizeD);
dfx     = diff(tenX, 1, 1);
dfy     = diff(tenY, 1, 2);
dfz     = diff(tenZ, 1, 3);

dfxT   = zeros(sizeD);
dfyT   = zeros(sizeD);
dfzT   = zeros(sizeD);
dfxT(1,:,:) = tenX(end, :, :) - tenX(1, :, :); %
dfxT(2:end,:,:) = -dfx;
dfyT(:,1,:)     =  tenY(:,end,:) - tenY(:,1,:);
dfyT(:,2:end,:) = -dfy;
dfzT(:,:,1)     = tenZ(:,:,end) - tenZ(:,:,1);
dfzT(:,:,2:end) = -dfz;

diffT_a = dfxT + dfyT + dfzT;
diffT_a = diffT_a(:);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  x^* = argmin_x 0.5*(x-a) + \lambda * |x|
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function x = softThres(a, tau)

x = sign(a).* max( abs(a) - tau, 0);
end


