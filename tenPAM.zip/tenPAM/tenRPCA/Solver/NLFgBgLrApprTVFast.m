function [x0, x1, x2, nois, out] = NLFgBgLrApprTVFast(A, y, sizeD, rk, lam, initX1, initX2, opts)
%------------------------------------------------------------------------------------------------------------------
% Model: min fai(E) + lam*||DX2||_1
%        s.t.  b = A*X0,     X0 = L + E + X2. 
% where X1 = L + E, L = (sum_i Rt_i * R_i)^(-1) ( sum_i Rt_i ([G_i;Ui1,Ui2,U3, Ui4]) ), 
%        fai(E) = 0.5*|| E ||^2 or ||E||_1
%
% Equivalent Model: min fai(E) + lam*||P||_1
%        s.t.  P = DX2,  b = A*(x0),  x0 = L + E + X2, b = A*X0;
% where X1 = L + E.
% 
%--------------------------------INPUTs------------------------------------------------------------------------------
% A: measurement operator
% y: measurement signal
% sizeD : size of original tensor data 
% rk : the rank of L
% lam: traded-off parameter
% opts:
%  - maxIter
%  - tol
%  - beta
%  - init_x0
%  - init_x2
%  - trX0
%  - trX1
%  - trX2
%  - cont: use continuation (true) or not (false).
%  - contpar: continuation parameter (<1).
%  - contfactor: continuatoin factor (>1).
%---------------------------------OUTPUTs---------------------------------------------------------------------------
% x1 : background
% x2 : foreground
% x0:  reconstructed video
% out: 
%  - time
%  - iter
%  - rsnrPath
%  - relChgX1Path
%  - relChgX2Path
%  - relErrX0Path
%  - relErrX1Path
%  - relErrX2Path
% -------------------------------------------------------------------------------------
%  contact: caowenf2006@163.com, yao.s.wang@gmail.com
%  Authors:  W.F. Cao and Yao Wang 
%  2015 - 7 - 7 , @ XJTU
%

%%  check and initilization
if ~exist('opts','var'); opts=[]; end
if isfield(opts,'tol');  tol = opts.tol; else tol = 1e-6; end;
if isfield(opts,'beta'); beta = opts.beta; else beta = ones(3,1)*1e-1/mean(abs(y(:))); end 
if isfield(opts,'gauss_frag'); gauss_frag = opts.gauss_frag; else gauss_frag = 1; end;
if isfield(opts,'win');    win = opts.win;   else    win = 8; end;
if isfield(opts,'nblk');   nblk = opts.nblk; else  nblk = 40; end;
if isfield(opts,'step');   step = opts.step; else  step = win - 1; end;
if isfield(opts,'hs');     hs = opts.hs; else   hs = 18; end;
if isfield(opts,'maxIter');maxIter = opts.maxIter; else maxIter = 60;end;
if isfield(opts,'trX0');   trX0 = opts.trX0; end;
if isfield(opts,'trX1');   trX1 = opts.trX1; end;
if isfield(opts,'trX2');   trX2 = opts.trX2; end;

if isfield(opts,'isCont')
    isCont = opts.isCont; contpar = opts.contpar; contfactor = opts.contfactor;
 else
    isCont = true; contpar = 0.95; contfactor = 1.15;
end
disp(opts);

%%% splitting variables and auxiliary variables 
N    = prod(sizeD);
h    = sizeD(1);
w    = sizeD(2);
d    = sizeD(3);

x0   = zeros(N,1);
nois = zeros(N,1);
p1  = zeros(3*N, 1);
v1  = zeros(3*N, 1);
v2  = zeros(N,1);
v3  = zeros(size(y));

% % pre processing  X1 X2
H             = fspecial('gaussian',9,0.8);
initX1        = imfilter(initX1,H, 'replicate'); % for enhacing non-local search
% initX11      = imfilter(initX1,H, 'replicate');
% initX11_mat  = Unfold(initX11,size(initX11),3);
% [U1,D1,V1]   = svd(initX11_mat,'econ');
% initX1       = Fold(U1(:,1:rk)*D1(1:rk,1:rk)*V1(:,1:rk)',size(initX11),3);
% for k = 1 : d
%     initX2(:,:,k) = medfilt2(initX2(:,:,k));
% end

Lr      = initX1(:); 
x1      = Lr;
x2      = initX2(:);

M      = h - win +1;
N      = w - win +1;
rGrid = 1: step : M;
rGrid = [rGrid rGrid(end)+1: M];
rGrid = unique(rGrid);
cGrid = 1: step : N;
cGrid = [cGrid cGrid(end)+1: N];
cGrid = unique(cGrid);
L        = M*N;
matIdx   = reshape(1:L,M,N);

libPch      = extractPch(initX1,h,w,d,win); % b x b x d x nPch
arrSimiIdx  = simiBlkMatch(libPch,rGrid,cGrid,matIdx,nblk,hs);
arrSimiPch  = collectSimiPch(libPch, arrSimiIdx);  % 
% engy        = 0.95;
if isfield(opts,'rk_nl'); rk_nl = opts.rk_nl; else rk_nl= 0.45;end; 
arrRank     = detectSimiRank(arrSimiPch, nblk, rk_nl); 

Eny_x    = (abs(psf2otf([+1; -1], [h,w,d]))).^2  ;
Eny_y    = (abs(psf2otf([+1, -1], [h,w,d]))).^2  ;
Eny_z    = (abs(psf2otf([+1, -1], [w,d,h]))).^2  ;
Eny_z    = permute(Eny_z, [3, 1 2]);
denom1   = Eny_x + Eny_y + Eny_z;

%% main loop
relErrX0Path = zeros(maxIter, 1);
relErrX1Path = zeros(maxIter, 1);
relErrX2Path = zeros(maxIter, 1);
rsnrPath     = zeros(maxIter, 1);
relChgX0Path = zeros(maxIter, 1);
relChgX1Path = zeros(maxIter, 1);
relChgX2Path = zeros(maxIter, 1);
stopPath     = zeros(maxIter, 1);
gamma    = 1.15;
display  = 1;
tic;
for iter = 1 : maxIter
    
    fprintf('\n*****************************iter: %d ******************************\n', iter');
    
    x0_pre = x0; x1_pre = x1; x2_pre = x2;
    
    %- x0 subproblem
    temp_x0  = v2 + beta(2)*(Lr + nois + x2) + A'*(beta(3)*y - v3);
    temp_x0  = temp_x0 / beta(2);
    x0  = temp_x0 - (  beta(3)/(beta(2)+beta(3)) )*( A'*(A*temp_x0) );
    Ax0 = A*x0;
    
    %- x1 Lr- subproblem
    temp_x1    = x0 - nois - x2 - v2/beta(2);
    libPch     = extractPch(reshape(temp_x1,sizeD), h, w, d, win); % extract patches
    arrSimiPch = collectSimiPch(libPch, arrSimiIdx);  % 
    arrSimiLr  = simiLrAppr(arrSimiPch, rk, arrRank, win); 
    Lr   = aggrePch(arrSimiLr,arrSimiIdx,sizeD);
    Lr   = Lr(:); x1 = Lr;
     
    if mod(iter, 10) == 0
           arrSimiIdx  = simiBlkMatch(libPch,rGrid,cGrid,matIdx,nblk,hs);
           arrRank     = detectSimiRank(arrSimiPch,nblk, rk_nl); 
    end
     
    %- E subproblem
    if  gauss_frag
         nois = beta(2) * ( x0 - Lr - x2 - v2/beta(2) ) / (beta(2) + 1);
    else
         nois = softThres( x0 - Lr - x2 - v2/beta(2), 1/beta(2));
    end
    
    %- x2 subproblem
    temp_x2  = x0 - Lr - nois;
    diffT_p1 = diffT3( beta(1)*p1 - v1, sizeD );
    numer1   = reshape( diffT_p1 + beta(2)*temp_x2 - v2, sizeD);
    x2  = real( ifftn( fftn(numer1) ./ (beta(1)*denom1 + beta(2)) ) );
    x2  = x2(:);
        
    %- P1  subproblem
    diff_x2 = diff3(x2, sizeD); 
    p1      = softThres( diff_x2 + v1/beta(1), lam/beta(1) );
     
    %- updating multipliers
	v1 = v1 - gamma*beta(1)*(p1 - diff_x2);
	v2 = v2 - gamma*beta(2)*(x0 - Lr - nois - x2);
	v3 = v3 - gamma*beta(3)*(y - Ax0);
    
    %- termination and saving some information
    if exist('trX0', 'var')
        relErrX0Path (iter) = norm(x0 - trX0(:))/ norm(trX0(:));
        if display
            fprintf('relErrX0: %4.4f \n', relErrX0Path (iter));
        end
    end
    
    if exist('trX1','var')
        relErrX1Path (iter) = norm(Lr - trX1(:)) / norm(trX1(:));
        if display
            fprintf('relErrX1: %4.4f \n', relErrX1Path (iter));
        end
    end
    
    if exist('trX2','var')
        relErrX2Path (iter) = norm(x2 - trX2(:)) / norm(trX2(:));
        if display
            fprintf('relErrX2: %4.4f \n', relErrX2Path (iter));
        end
    end
    
    if exist('trX0','var')
        rsnrPath(iter) = SNR( x0, trX0(:) );
        if display
            fprintf('rsnr: %4.4f\n', rsnrPath(iter));
        end
    end
    
    relChgX0 = norm(x0 - x0_pre,'fro')/max(1,norm(x0_pre,'fro'));
    relChgX1 = norm(x1 - x1_pre,'fro')/max(1,norm(x1_pre,'fro'));
    relChgX2 = norm(x2 - x2_pre,'fro')/max(1,norm(x2_pre,'fro'));
    relChgX0Path(iter) = relChgX0;
    relChgX1Path(iter) = relChgX1;
    relChgX2Path(iter) = relChgX2;
	if display
      fprintf('relChgX0:%4.4e,     relChgX1: %4.4e \n              relChgX2: %4.4e\n', relChgX0, relChgX1,relChgX2);
    end
    
    stopCond = norm(Ax0 - y)/norm(y);
    stopPath(iter) = stopCond;
    fprintf('stopFormulaVal: %4.4e \n', stopCond);
    if (iter> 50) &&  (stopCond < tol ) 
          disp(' !!!stopped by termination rule!!! ');  break;
    end
    
    %- continuation
     if  isCont
            nr1 = norm(p1 - diff_x2, 'fro');
            nr2 = norm(x0 - Lr - nois - x2, 'fro');
            nr3 = norm(y - Ax0, 'fro');

            if iter >1 && nr1 > contpar * nr1_pre
                beta(1) = contfactor*beta(1);
            end
            if iter>1 && nr2 > contpar * nr2_pre
                beta(2) = contfactor*beta(2);
            end
            if iter>1 && nr3 > contpar * nr3_pre
                beta(3) = contfactor*beta(3);
            end
            
            if display

              fprintf('nr1(p1-diff_x2): %4.4e,  nr2(x0 - Lr - nois -x2): %4.4e, \n            nr3(y-Ax0): %4.4e\n', nr1, nr2, nr3);
            end
      
            nr1_pre =nr1;   nr2_pre = nr2;   nr3_pre = nr3;
     end    
    
end


%% ouput

out.time     = toc;
out.iter     = iter;
out.p1       = p1; 
out.nois     = nois;
out.stopPath = stopPath(1:iter);
out.relChgX0Path = relChgX0Path(1:iter);
out.relChgX1Path = relChgX1Path(1:iter);
out.relChgX2Path = relChgX2Path(1:iter);

if exist('trX0','var')
    out.rsnrPath     = rsnrPath(1:iter);
    out.relErrX0Path = relErrX0Path(1:iter) ;
end
if exist('trX1','var')
      out.relErrX1Path = relErrX1Path(1:iter) ;
end
if exist('trX2','var')
      out.relErrX2Path = relErrX2Path(1:iter) ;
end

return;

end


%%  subFunctions
%%%%%%%%%%%%%%%%%%%%%% subroutines %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% compute the diff. of one 3-order tensor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function diff_x = diff3(x,  sizeD)

tenX   = reshape(x, sizeD);

dfx1     = diff(tenX, 1, 1);
dfy1     = diff(tenX, 1, 2);
dfz1     = diff(tenX, 1, 3);

dfx       = zeros(sizeD);
dfy       = zeros(sizeD);
dfz       = zeros(sizeD);
dfx(1:end-1,:,:)  = dfx1;
dfx(end,:,:)        =  tenX(1,:,:) - tenX(end,:,:);
dfy(:,1:end-1,:) = dfy1;
dfy(:,end,:)        = tenX(:,1,:) - tenX(:,end,:);
dfz(:,:,1:end-1) = dfz1;
dfz(:,:,end)        = tenX(:,:,1) - tenX(:,:,end);

diff_x = [dfx(:); dfy(:); dfz(:)];
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%$%%%%%
%  compute the inverse-diff. of one 3-order tensor (3*N)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function diffT_a = diffT3(a, sizeD)

N      = prod(sizeD);
tenX   = reshape(a(1: N), sizeD);
tenY   = reshape(a((N+1):2*N), sizeD);
tenZ   = reshape(a((2*N+1):3*N), sizeD);

dfx     = diff(tenX, 1, 1);
dfy     = diff(tenY, 1, 2);
dfz     = diff(tenZ, 1, 3);

dfxT   = zeros(sizeD);
dfyT   = zeros(sizeD);
dfzT   = zeros(sizeD);
dfxT(1,:,:) = tenX(end, :, :) - tenX(1, :, :); %
dfxT(2:end,:,:) = -dfx;
dfyT(:,1,:) =  tenY(:,end,:) - tenY(:,1,:);
dfyT(:,2:end,:) = -dfy;
dfzT(:,:,1) = tenZ(:,:,end) - tenZ(:,:,1);
dfzT(:,:,2:end) = -dfz;

diffT_a = dfxT + dfyT + dfzT;
diffT_a = diffT_a(:);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  x^* = argmin_x 0.5*(x-a) + \lambda * |x|
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function x = softThres(a, tau)

x = sign(a).* max( abs(a) - tau, 0);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function arrRank    = detectSimiRank(arrSimiPch,nblk, engy)

nCls    = numel(arrSimiPch);
arrRank = zeros(nCls,1);
for o = 1 : nCls
%      simiPch        = arrSimiPch{o};
%      flatPches      = Unfold(simiPch,size(simiPch),4);
%      [u,s,v]        = svd(flatPches,'econ');
%      ds             = diag(s); 
%      ratio          = cumsum(ds)/sum(ds);
%      arrRank(o)     = sum(ratio<=engy);  %c0 = 0.005
     arrRank(o) = ceil(nblk*engy);  %%%
end;
% sz=[];
% for o = 1 : nCls
%     sz = [sz,sum(idxCls==o)];
% end
end

function [arrSimiLr]  = simiLrAppr(arrSimiPch,rk,arrRank,win)
% sum_o || R_o[x] - Lr_o||^2, Lr_o = [G_o;Uo1,Uo2,U3,Uo4]
% where Uo1,Uo2,U3,Uo4, are orthgonal, and U3 is shared factor.
%
nCls     = numel(arrSimiPch);
celX     = cell(nCls,1);
rankArr  = zeros(nCls,4);
for o = 1 : nCls 
      celX{o}      = arrSimiPch{o};
      rankArr(o,:) = [win,win,rk,arrRank(o)];
end
mode_s   = 3;
warning('off');
arrSimiLr = factorSharedTuckerAls(celX,rankArr,mode_s,'tol',1e-6);
end


function [aveLr,Lr,Weig] = aggrePch(arrSimiLr,arrSimiIdx,sizeD)

nCls  = numel(arrSimiLr);
win   = size(arrSimiLr{1},1);
nfrm  = size(arrSimiLr{1},3);
row   = sizeD(1);
col   = sizeD(2);
npch  = (row-win+1)*(col-win+1);
libPch = zeros(win,win,nfrm,npch);
weig   = zeros(win,win,nfrm,npch);
for o = 1 : nCls
    libPch(:,:,:,arrSimiIdx(:,o)) = libPch(:,:,:,arrSimiIdx(:,o)) + arrSimiLr{o};
    weig(:,:,:,arrSimiIdx(:,o))   = weig(:,:,:,arrSimiIdx(:,o)) + 1;
end

Lr    = zeros(sizeD);
Weig  = zeros(sizeD);
N     = col - win +1;
M     = row - win +1;
cnt   = 1;
for c = 1 : N
    for r = 1 : M
    
         Lr(r:r+win-1,c:c+win-1,:)   =  Lr(r:r+win-1,c:c+win-1,:)  + libPch(:,:,:,cnt);
         Weig(r:r+win-1,c:c+win-1,:) =  Weig(r:r+win-1,c:c+win-1,:)+ weig(:,:,:,cnt);
         cnt = cnt + 1;
   end
end
aveLr  = Lr./Weig;
end

function [libPch]   = extractPch(X,nRow,nCol,nfrm,win)

M     = nRow - win + 1;
N     = nCol - win + 1;
libPch = zeros(win,win,nfrm,M*N);

cnt =0;
for c = 1 : N
    for r = 1 : M
        
        cnt  = cnt +1;
        ridx = r;      cidx = c;
        libPch(:,:,:,cnt) = X(ridx:ridx+win-1,cidx:cidx+win-1,:);
    end
end
end

function arrSimiPch = collectSimiPch(libPch,arrSimiIdx)

[~,nCls]      = size(arrSimiIdx);
arrSimiPch    = cell(nCls,1);
for k = 1 : nCls
    arrSimiPch{k} = libPch(:,:,:,arrSimiIdx(:,k));
end

end

function arrSimiIdx = simiBlkMatch(libPch,rGrid,cGrid,matIdx,nblk,hs)

[M,N] = size(matIdx);
M1    = numel(rGrid);
N1    = numel(cGrid);
arrSimiIdx       = zeros(nblk,M1*N1);
[~,win,nfrm,n]   = size(libPch);
Pches            = reshape(libPch,win*win*nfrm,n);
cnt  = 1;
for j = 1 : N1
    for i = 1 : M1
    
         rdx    = rGrid(i); cdx = cGrid(j);
         objIdx = matIdx(rdx,cdx);
         objPch = Pches(:,objIdx);

         r1    = max(1, rdx - hs); 
         r2    = min(M,rdx + hs);
         c1    = max(1, cdx - hs);
         c2    = min(N,cdx + hs);

         selIdx  = matIdx(r1:r2,c1:c2);
         selPch  = Pches(:,selIdx(:));

         res     = bsxfun(@minus,selPch,objPch);
         resDist = sum(res.^2,1);
         [~,idx] = sort(resDist);

         arrSimiIdx(:,cnt) = selIdx(idx(1:nblk));
         cnt = cnt +1;
     end
end  

end
