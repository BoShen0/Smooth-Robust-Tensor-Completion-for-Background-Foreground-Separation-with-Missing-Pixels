function  [ ssim ] = SSIM(image0, image)


 [ssim, ssim_map] = ssim_index2(image0, image);
end
