function [fmax,pre,rec, S, bestTH] = findFMeasureNew(E, S0, numberThred)
  % E is the estimation
  % S0 is the ground truth
  % numberThred is the length of search space.
    fmax = 0;
    pre = 0;
    rec = 0;
    Vth = linspace(min(abs(E(:))), max(abs(E(:))), numberThred);
    for idx = 1:length(Vth)
        th = Vth(idx);
        Stmp = abs(E) > th;
        [pretmp, rectmp] = countPR(S0, Stmp);
        ftmp = 2*rectmp*pretmp/(pretmp+rectmp);
        if ~isnan(ftmp) && ftmp > fmax
            fmax = ftmp;
            S = Stmp;
            pre = pretmp;
            rec = rectmp;
            bestTH = th;
        end
    end
    
    if fmax == 0
        S = Stmp;
        pre = pretmp;
        rec = rectmp;
        bestTH = 0;
    end
end