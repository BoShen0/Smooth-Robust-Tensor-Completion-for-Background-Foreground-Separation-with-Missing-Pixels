function yI0 = intensityTrans(xI0,minI0,maxI0)

[h,w,d] = size(xI0);
maxV    = max(xI0(:));
minV    = ceil(0.75*maxV);
yI0     = xI0;
for i = 1 : h
    for j = 1:w
        for k = 1:d
            
           if xI0(i,j,k)>minV && xI0(i,j,k)<maxV
              yI0(i,j,k) = floor((xI0(i,j,k) - minV)*(maxI0 - minI0)/(maxV - minV) + minI0);
           end
            
        end
    end
end


end
            
            
