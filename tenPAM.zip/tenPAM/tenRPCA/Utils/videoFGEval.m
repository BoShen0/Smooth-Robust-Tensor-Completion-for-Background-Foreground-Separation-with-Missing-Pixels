function [fScore,precision,recall, Mask,Thres] = videoFGEval(tenS,xs2,sizeD,numberThred)

% tensorS is the ground truth mask
% xs2 is the estimated foreground

nFrm      = sizeD(3);
recTenS    = reshape(xs2,sizeD);
fScore     = zeros(1, nFrm);
precision     = zeros(1, nFrm);
recall    = zeros(1, nFrm);

Thres      = zeros(1, nFrm);
Mask       = zeros(sizeD);
for i = 1 : nFrm
   [fScore(i),precision(i),recall(i), Mask(:,:,i), Thres(i)] = findFMeasureNew(recTenS(:,:,i),  tenS(:,:,i),numberThred);
end

end


