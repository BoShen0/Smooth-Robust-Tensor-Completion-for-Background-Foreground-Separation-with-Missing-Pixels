function  [vPsnr1, vSsim1,vSsim2, vRSE] = videoRealEval(X0, Xrec, sizeD)


nFrm      = sizeD(3);
X0        = reshape(X0, sizeD);
Xrec      = reshape(Xrec, sizeD);
vPsnr1  = zeros(1, nFrm);
vSsim1  = zeros(1, nFrm);
for i = 1 : nFrm
    vPsnr1(i)  = PSNR2(X0(:,:,i), Xrec(:,:,i));
    
    vSsim1(i)  = SSIM(X0(:,:,i), Xrec(:,:,i));
    
    vSsim2(i)  = ssim( Xrec(:,:,i), X0(:,:,i));
     
    vRSE(i) = norm(Xrec(:,:,i)-X0(:,:,i),'fro')/norm(X0(:,:,i),'fro');
end

end
