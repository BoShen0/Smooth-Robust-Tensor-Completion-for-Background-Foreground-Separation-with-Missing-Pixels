function [vecPsnr1, vecSsim1, vecPsnr2, vecSsim2, fScore,Mask,Thres] = videoSimuEval(tenD,tenB,tenS,xs0,xs1,xs2,sizeD,numberThred)

% psnr1   = PSNR(tenD(:), xs1+xs2);
% ssim1   = SSIM(tenD, xs1+xs2, sizeD);
% 
% psnr2   = PSNR(tenB(:), xL(:));
% ssim2   = SSIM(tenB, xs1, sizeD);

nFrm      = sizeD(3);
recTenD   = reshape(xs0, sizeD);
recTenB   = reshape(xs1, sizeD);
vecPsnr1 = zeros(1, nFrm);
vecPsnr2 = zeros(1, nFrm);
vecSsim1 = zeros(1, nFrm);
vecSsim2 = zeros(1, nFrm);
for i = 1 : nFrm
    vecPsnr1(i) = PSNR(tenD(:,:,i), recTenD(:,:,i));
    vecPsnr2(i) = PSNR(tenB(:,:,i), recTenB(:,:,i));
    
    vecSsim1(i)  = SSIM(tenD(:,:,i), recTenD(:,:,i));
    vecSsim2(i)  = SSIM(tenB(:,:,i), recTenB(:,:,i));
end

recTenS    = reshape(xs2,sizeD);
fScore     = zeros(1, nFrm);
Thres      = zeros(1, nFrm);
Mask       = zeros(sizeD);
for i = 1 : nFrm
   [fScore(i), Mask(:,:,i), Thres(i)] = findFMeasure(recTenS(:,:,i),  tenS(:,:,i));
end

end


