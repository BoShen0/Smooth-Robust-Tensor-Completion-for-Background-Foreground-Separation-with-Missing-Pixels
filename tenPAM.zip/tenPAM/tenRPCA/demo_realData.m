

clc, clear classes, close all;

%% Include files
seed   = 2015; 
fprintf('Seed = %d\n',seed);
RandStream.setGlobalStream(RandStream('mt19937ar','seed',seed));
addpath(genpath([cd,'\']));

% sp     =  25;      % inverse sampling ratio
% ratio  =  1/sp;    % ratio
% rk_t   =  1;       % rank for temporal mode
% currResults = [cd, '\Results\ShoppingMall_2015_8_10_Raito', num2str(ratio),'\'];
% mkdir(currResults); 
rk_t   =  1;

%% Generating the compressive measurements 
param.scale     = [256, 256];
param.grayFrag  = 1;
param.startIdx  = 1481;
param.endIdx    = 1508; %1608
frame_idx       = [1481, 1508]; %1608
param.partFName  = 'ShoppingMall';%
param.fileFormat = 'bmp'; %'jpg'
inputFolder      = [cd, '\Data\ShoppingMall\']; 
D0                     = dataLoad(inputFolder,param);
[height, width,  nfrm] = size(D0);
D                      = D0;
sizeD                  = size(D);

displayVideo(D);

% compressive measurements
% N     =  height*width;
% A     =  PermuteWHT2(N, nfrm, ratio);
% b     =  A*D(:);
ObservedRatio = 0.5;
Nelement = height*width*nfrm;
% Omega = zeros(Nelement,1);
rng(10)
indexSet = randperm(Nelement);
Omega = indexSet(1:floor(Nelement * ObservedRatio));


D_temp = D(:);
b = D_temp(Omega);
%%  FgBgLrApprTVFast
clear opts;
opts.maxIter    = 100; %250
opts.tol        = 1e-6;
opts.trX0       = D;
opts.gauss_frag = 1;

tucker_rk = [ceil(height*0.95), ceil(width*0.95),rk_t];
rk1       = tucker_rk;   
lam1      = 0.5;

opts.maxIter    = 30; %250
beta = ones(3,1)*1e-0/mean(abs(opts.trX0(:))); beta(2) = 4e-1/mean(abs(opts.trX0(:)));
opts.beta = beta;  % maxIter = 100, 1e+1,4e-1, lam1 = 0.55;

[tenX0, tenX1, tenX2, tenOut] = FgBgLrApprTVFastTCnew_Obj(Omega, b, sizeD, rk1, lam1, opts);

semilogy(tenOut.objValuePath)
semilogy(tenOut.relChgX0Path)
semilogy(tenOut.relChgX1Path)
semilogy(tenOut.relChgX2Path)
semilogy(tenOut.relChgU1Path)
semilogy(tenOut.relChgU2Path)
semilogy(tenOut.relChgU3Path)

[tenX0, tenX1, tenX2, tenNoi, tenOut] = FgBgLrApprTVFastTC(Omega, b, sizeD, rk1, lam1, opts);
[tenX0, tenX1, tenX2, tenOut] = FgBgLrApprTVFastTCnew(Omega, b, sizeD, rk1, lam1, opts);
[tenX0, tenX1, tenX2, tenOut] = FgBgLrApprTVFastTCnew1(Omega, b, sizeD, rk1, lam1, opts);
[tenX0, tenX1, tenX2, tenOut] = FgBgLrApprTVFastTCnew1updated(Omega, b, sizeD, rk1, lam1, opts);
[tenX0, tenX1, tenX2, tenOut] = FgBgLrApprTVFastTCnew2(Omega, b, sizeD, rk1, lam1, opts);

[PSNR1, SSIM1]  = videoRealEval(D, tenX0, sizeD);

avePSNR1        = mean(PSNR1)
aveSSIM1        = mean(SSIM1)

%%% display
tenX0  = reshape(tenX0,sizeD);
tenX1  = reshape(tenX1,sizeD);
tenX2  = reshape(tenX2,sizeD);
tenNoi = reshape(tenNoi,sizeD);


displayVideo(tenX0);
displayVideo(tenX1);
displayVideo(tenX2);
% displayVideo(tenX0 + tenNoi);
% %%% saving the experimental results
% save(strcat(currResults,'FgBgTen_WHT_frame_lam_',num2str(lam1),'.mat'), 'D', 'tenX0','tenX1','tenX2','tenNoi', ...
%                                                              'tenOut','PSNR1','SSIM1','avePSNR1','aveSSIM1'); 
% 
% %% NLFgBgLrApprTVFast
% clear opts;
% opts.tol         = 5e-5;
% opts.trX0        = D;
% opts.maxIter     = 60;
% opts.gauss_frag  = 1;
% 
% str = strcat(currResults,'FgBgTen_WHT_frame_lam_',num2str(lam1),'.mat');
% load(str);
% initX1       = reshape(tenX1,sizeD);              
% initX2       = reshape(tenX2,sizeD);
% 
% rk           = rk_t;     % rank for the temporal mode
% lam2         = 0.05;
% 
% 
% [tenX0_nl, tenX1_nl,tenX2_nl,tenNoi_nl, tenOut_nl] = NLFgBgLrApprTVFast(A,b,sizeD,rk,lam2,initX1,initX2,opts);
% 
% 
% [PSNR1_nl, SSIM1_nl]  = videoRealEval(D, tenX0_nl, sizeD);
% avePSNR2 = mean(PSNR1_nl)
% aveSSIM2 = mean(SSIM1_nl)
% 
% 
% %%% display
% tenX0_nl = reshape(tenX0_nl,sizeD);
% tenX1_nl = reshape(tenX1_nl,sizeD);
% tenX2_nl = reshape(tenX2_nl,sizeD);
% 
% displayVideo(tenX0_nl);
% displayVideo(tenX1_nl);
% displayVideo(tenX2_nl);
% 
% %%% saving the experimental results
% save(strcat(currResults,'FgBgTenNL_WHT_frame_lam_',num2str(lam2),'.mat'), 'D', 'tenX0_nl','tenX1_nl','tenX2_nl','tenNoi_nl', ...
%                                                                    'tenOut_nl','PSNR1_nl','SSIM1_nl','avePSNR2','aveSSIM2'); 