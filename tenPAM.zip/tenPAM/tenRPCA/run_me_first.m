% mex the fdWHtrans.cpp script file

cd Operator\@PermuteWHT2\

mex fdWHtrans.cpp;

cd ..
cd ..